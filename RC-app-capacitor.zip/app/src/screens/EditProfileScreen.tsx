import { useState } from 'react';
import { ArrowLeft, Camera } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function EditProfileScreen() {
  const { state, dispatch } = useApp();
  const user = state.currentUser;
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);

  if (!user) return null;

  const avatars = [
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1599566150163-29194dcabd9c?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
    'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop',
  ];

  const handleSave = () => {
    dispatch({ type: 'UPDATE_PROFILE', user: { displayName, bio } });
    dispatch({ type: 'SHOW_TOAST', message: 'Profil berhasil diperbarui!' });
    setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
    dispatch({ type: 'GO_BACK' });
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="font-semibold text-base">Edit Profil</span>
        </h1>
        <button
          onClick={handleSave}
          className="text-amber-600 font-semibold text-sm"
        >
          Simpan
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-5">
        {/* Avatar */}
        <div className="flex flex-col items-center">
          <button
            onClick={() => setShowPhotoPicker(!showPhotoPicker)}
            className="relative"
          >
            <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-2 border-amber-400">
              {user.avatar ? (
                <img src={user.avatar} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-3xl font-bold text-gray-400">{displayName?.[0] || 'U'}</span>
              )}
            </div>
            <div className="absolute bottom-0 right-0 w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center border-2 border-white">
              <Camera className="w-4 h-4 text-white" />
            </div>
          </button>
          <button
            onClick={() => setShowPhotoPicker(!showPhotoPicker)}
            className="text-amber-600 text-sm font-medium mt-2"
          >
            Ganti Foto Profil
          </button>
        </div>

        {/* Avatar Picker */}
        {showPhotoPicker && (
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
            {avatars.map((url, i) => (
              <button
                key={i}
                onClick={() => {
                  dispatch({ type: 'UPDATE_PROFILE', user: { avatar: url } });
                  setShowPhotoPicker(false);
                }}
                className="shrink-0"
              >
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-gray-200 hover:border-amber-400 transition-colors">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Form */}
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Nama Lengkap</label>
            <input
              type="text"
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              className="w-full h-12 bg-gray-100 rounded-xl px-4 text-[15px] focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">ID Pengguna</label>
            <input
              type="text"
              value={`@${user.username}`}
              readOnly
              className="w-full h-12 bg-gray-50 rounded-xl px-4 text-[15px] text-gray-400"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Bio</label>
            <textarea
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Ceritakan tentang diri Anda..."
              maxLength={150}
              className="w-full h-24 bg-gray-100 rounded-xl p-4 text-[15px] resize-none focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <p className="text-gray-400 text-xs text-right mt-1">{bio.length}/150</p>
          </div>
        </div>
      </div>
    </div>
  );
}
