import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, AtSign, Lock, CheckCircle2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function RegisterScreen() {
  const { dispatch } = useApp();
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const getPasswordStrength = (pw: string) => {
    if (!pw) return 0;
    let s = 0;
    if (pw.length >= 6) s++;
    if (pw.length >= 10) s++;
    if (/[A-Z]/.test(pw) && /[0-9]/.test(pw)) s++;
    return Math.min(s, 3);
  };

  const strength = getPasswordStrength(password);
  const strengthColors = ['bg-red-500', 'bg-yellow-500', 'bg-green-500', 'bg-green-600'];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!userId.trim()) errs.userId = 'ID pengguna wajib diisi';
    else if (!/^[a-zA-Z0-9_]+$/.test(userId)) errs.userId = 'ID hanya boleh huruf, angka, dan underscore';
    if (!password) errs.password = 'Kata sandi wajib diisi';
    else if (password.length < 6) errs.password = 'Kata sandi minimal 6 karakter';
    if (password !== confirmPassword) errs.confirm = 'Kata sandi tidak cocok';
    if (!agreed) errs.agreed = 'Anda harus menyetujui ketentuan';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleRegister = () => {
    if (!validate()) return;
    dispatch({
      type: 'LOGIN',
      user: {
        id: 'current-user',
        username: userId,
        displayName: userId,
        bio: '',
        avatar: '',
        followers: 0,
        following: 0,
        likes: 0,
      },
    });
    dispatch({ type: 'SHOW_TOAST', message: 'Akun berhasil dibuat! Selamat datang.' });
    setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
  };

  return (
    <div className="h-full flex flex-col dark-gradient overflow-y-auto no-scrollbar">
      {/* Header */}
      <div className="flex items-center px-4 h-14 shrink-0">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <h1 className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="text-white font-semibold text-lg">Buat Akun</span>
        </h1>
      </div>

      {/* Form */}
      <div className="flex-1 px-6 py-6 space-y-4">
        {/* ID */}
        <div>
          <label className="text-gray-300 text-sm font-medium mb-1.5 block">ID Pengguna</label>
          <div className="relative">
            <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              value={userId}
              onChange={e => setUserId(e.target.value)}
              placeholder="Pilih ID unik Anda"
              className="w-full h-[50px] bg-white/10 border border-white/20 rounded-xl pl-11 pr-4 text-white placeholder-gray-500 text-[15px] focus:outline-none focus:border-amber-500 transition-colors"
            />
          </div>
          <p className="text-gray-500 text-xs mt-1">ID hanya boleh huruf, angka, dan underscore</p>
          {errors.userId && <p className="text-red-400 text-xs mt-1">{errors.userId}</p>}
        </div>

        {/* Password */}
        <div>
          <label className="text-gray-300 text-sm font-medium mb-1.5 block">Kata Sandi</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Min. 6 karakter"
              className="w-full h-[50px] bg-white/10 border border-white/20 rounded-xl pl-11 pr-12 text-white placeholder-gray-500 text-[15px] focus:outline-none focus:border-amber-500 transition-colors"
            />
            <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
          {/* Strength */}
          <div className="flex gap-1 mt-2">
            {[0, 1, 2].map(i => (
              <div key={i} className={`h-1 flex-1 rounded-full transition-colors ${i < strength ? strengthColors[strength - 1] : 'bg-gray-700'}`} />
            ))}
          </div>
          {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password}</p>}
        </div>

        {/* Confirm Password */}
        <div>
          <label className="text-gray-300 text-sm font-medium mb-1.5 block">Konfirmasi Kata Sandi</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={e => setConfirmPassword(e.target.value)}
            placeholder="Ulangi kata sandi"
            className="w-full h-[50px] bg-white/10 border border-white/20 rounded-xl px-4 text-white placeholder-gray-500 text-[15px] focus:outline-none focus:border-amber-500 transition-colors"
          />
          {password && confirmPassword && password === confirmPassword && (
            <div className="flex items-center gap-1 mt-1">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span className="text-green-500 text-xs">Kata sandi cocok</span>
            </div>
          )}
          {errors.confirm && <p className="text-red-400 text-xs mt-1">{errors.confirm}</p>}
        </div>

        {/* Agreement */}
        <label className="flex items-start gap-3 cursor-pointer pt-2">
          <input
            type="checkbox"
            checked={agreed}
            onChange={e => setAgreed(e.target.checked)}
            className="w-5 h-5 rounded border-gray-500 accent-amber-500 mt-0.5"
          />
          <span className="text-gray-400 text-sm leading-relaxed">
            Saya setuju dengan{' '}
            <button className="text-amber-400 underline">Ketentuan Layanan</button>
            {' '}dan{' '}
            <button className="text-amber-400 underline">Kebijakan Privasi</button>
          </span>
        </label>
        {errors.agreed && <p className="text-red-400 text-xs">{errors.agreed}</p>}

        {/* Register Button */}
        <button
          onClick={handleRegister}
          className="w-full h-[52px] gold-gradient rounded-xl text-white font-semibold text-base shadow-lg shadow-amber-500/30 active:scale-[0.97] transition-transform mt-4"
        >
          Daftar
        </button>

        {/* Login Link */}
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', screen: 'login' })}
          className="w-full text-center text-gray-400 text-sm mt-2"
        >
          Sudah punya akun? <span className="text-amber-400 font-medium">Masuk</span>
        </button>
      </div>
    </div>
  );
}
