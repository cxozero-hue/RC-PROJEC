import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Phone, MoreVertical, Send, Paperclip } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function ChatDetailScreen() {
  const { state, dispatch } = useApp();
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const conv = state.conversations.find(c => c.id === state.selectedChatId);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conv?.messages.length]);

  if (!conv) return null;

  const handleSend = () => {
    if (!input.trim()) return;
    dispatch({ type: 'SEND_MESSAGE', chatId: conv.id, message: input.trim() });
    setInput('');
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b bg-white z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
            <span className="text-xs font-bold">{conv.user.displayName[0]}</span>
          </div>
          <div>
            <p className="font-semibold text-sm">{conv.user.displayName}</p>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
              <p className="text-green-600 text-[11px]">Online</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="w-10 h-10 flex items-center justify-center">
            <Phone className="w-5 h-5 text-gray-600" />
          </button>
          <button className="w-10 h-10 flex items-center justify-center">
            <MoreVertical className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-3">
        {conv.messages.map(msg => {
          const isMe = msg.senderId === 'current-user';
          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                isMe
                  ? 'bg-amber-500 text-white rounded-br-md'
                  : 'bg-gray-100 text-gray-800 rounded-bl-md'
              }`}>
                <p className="text-sm">{msg.content}</p>
                <p className={`text-[10px] mt-1 ${isMe ? 'text-amber-100' : 'text-gray-400'}`}>
                  {msg.timestamp}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input Bar */}
      <div className="shrink-0 border-t bg-white px-4 py-2 flex items-center gap-2">
        <button className="w-10 h-10 flex items-center justify-center">
          <Paperclip className="w-5 h-5 text-gray-500" />
        </button>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Tulis pesan..."
          className="flex-1 h-10 bg-gray-100 rounded-full px-4 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          onClick={handleSend}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
            input.trim() ? 'bg-amber-500' : 'bg-gray-200'
          }`}
        >
          <Send className={`w-5 h-5 ${input.trim() ? 'text-white' : 'text-gray-400'}`} />
        </button>
      </div>
    </div>
  );
}
