import { useState } from 'react';
import { ArrowLeft, Edit3, Bell, MessageCircle } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function ChatListScreen() {
  const { state, dispatch } = useApp();
  const [activeMsgTab, setActiveMsgTab] = useState<'messages' | 'notifications'>('messages');

  const unreadCount = state.conversations.reduce((sum, c) => sum + c.unread, 0);
  const unreadNotifs = state.notifications.filter(n => !n.read).length;

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="font-heading text-lg font-bold">Pesan</span>
        </h1>
        <button className="w-10 h-10 flex items-center justify-center relative">
          <Edit3 className="w-5 h-5" />
        </button>
      </div>

      {/* Tabs */}
      <div className="shrink-0 flex border-b mx-4">
        <button
          onClick={() => setActiveMsgTab('messages')}
          className={`flex-1 flex items-center justify-center gap-1.5 pb-2.5 text-sm font-medium border-b-2 transition-colors ${
            activeMsgTab === 'messages' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-400'
          }`}
        >
          <MessageCircle className="w-4 h-4" />
          Pesan
          {unreadCount > 0 && (
            <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unreadCount}</span>
          )}
        </button>
        <button
          onClick={() => setActiveMsgTab('notifications')}
          className={`flex-1 flex items-center justify-center gap-1.5 pb-2.5 text-sm font-medium border-b-2 transition-colors ${
            activeMsgTab === 'notifications' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-400'
          }`}
        >
          <Bell className="w-4 h-4" />
          Notifikasi
          {unreadNotifs > 0 && (
            <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unreadNotifs}</span>
          )}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {activeMsgTab === 'messages' ? (
          <div>
            {state.conversations.map(conv => (
              <button
                key={conv.id}
                onClick={() => dispatch({ type: 'SET_SELECTED_CHAT', chatId: conv.id })}
                className="w-full flex items-start gap-3 px-4 py-3 text-left border-b border-gray-50 active:bg-gray-50 transition-colors"
              >
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                    <span className="font-bold text-gray-600">{conv.user.displayName[0]}</span>
                  </div>
                  {conv.unread > 0 && (
                    <div className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-[10px] font-bold">{conv.unread}</span>
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className={`text-sm ${conv.unread > 0 ? 'font-bold' : 'font-medium'}`}>{conv.user.displayName}</p>
                    <span className="text-gray-400 text-xs">{conv.timestamp}</span>
                  </div>
                  <p className={`text-sm truncate mt-0.5 ${conv.unread > 0 ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>
                    {conv.lastMessage}
                  </p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div>
            {state.notifications.map(notif => (
              <button
                key={notif.id}
                onClick={() => dispatch({ type: 'READ_NOTIFICATION', notifId: notif.id })}
                className={`w-full flex items-start gap-3 px-4 py-3 text-left border-b border-gray-50 active:bg-gray-50 transition-colors ${
                  !notif.read ? 'bg-amber-50/30' : ''
                }`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  notif.type === 'like' ? 'bg-red-100' :
                  notif.type === 'comment' ? 'bg-blue-100' :
                  notif.type === 'follow' ? 'bg-green-100' :
                  notif.type === 'mention' ? 'bg-purple-100' :
                  'bg-gray-100'
                }`}>
                  {notif.type === 'like' && <span className="text-red-500 text-lg">❤️</span>}
                  {notif.type === 'comment' && <span className="text-blue-500 text-lg">💬</span>}
                  {notif.type === 'follow' && <span className="text-green-500 text-lg">👤</span>}
                  {notif.type === 'mention' && <span className="text-purple-500 text-lg">@</span>}
                  {notif.type === 'system' && <span className="text-gray-500 text-lg">🔔</span>}
                </div>
                <div className="flex-1">
                  <p className={`text-sm ${!notif.read ? 'font-medium' : ''}`}>
                    {notif.user ? <span className="font-semibold">@{notif.user.username}</span> : ''} {notif.message}
                  </p>
                  <p className="text-gray-400 text-xs mt-0.5">{notif.timestamp}</p>
                </div>
                {!notif.read && <div className="w-2 h-2 bg-amber-500 rounded-full mt-2 shrink-0" />}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
