import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

export interface PickedImage {
  file: File;
  previewUrl: string;
}

/**
 * Konversi data URI base64 ke File object, supaya jalur upload
 * yang sudah ada (Supabase Storage) tidak perlu diubah.
 */
function dataUrlToFile(dataUrl: string, filename: string): File {
  const [header, base64] = dataUrl.split(',');
  const mimeMatch = header.match(/data:(.*?);base64/);
  const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new File([bytes], filename, { type: mime });
}

/**
 * Buka galeri foto pengguna. Di Android/iOS native (lewat Capacitor),
 * ini memakai plugin Camera resmi yang menangani permission otomatis.
 * Di web browser biasa, caller sebaiknya pakai <input type="file"> manual
 * karena plugin Capacitor tidak berjalan di browser biasa.
 */
export async function pickImageFromGallery(): Promise<PickedImage | null> {
  if (!Capacitor.isNativePlatform()) {
    return null; // caller harus fallback ke <input type="file">
  }

  try {
    const photo = await Camera.getPhoto({
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Photos,
      quality: 80,
      width: 1600,
    });

    if (!photo.dataUrl) return null;

    const filename = `photo-${Date.now()}.${photo.format ?? 'jpg'}`;
    const file = dataUrlToFile(photo.dataUrl, filename);

    return { file, previewUrl: photo.dataUrl };
  } catch (err) {
    // Pengguna membatalkan pemilihan gambar, atau permission ditolak
    console.warn('pickImageFromGallery dibatalkan atau gagal:', err);
    return null;
  }
}

export function isNativePlatform(): boolean {
  return Capacitor.isNativePlatform();
}
