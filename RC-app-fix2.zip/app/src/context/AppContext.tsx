import React, { createContext, useContext, useEffect, useReducer } from 'react';
import type { Screen, Tab, User, VideoPost, Article, Poem, ShortStory, ChatConversation, ChatMessage, Notification } from '@/types';
import { getCurrentSession, getProfile, onAuthStateChange } from '@/lib/authService';
import { fetchConversations } from '@/lib/chatService';

interface AppState {
  screen: Screen;
  prevScreen: Screen | null;
  activeTab: Tab;
  isAuthenticated: boolean;
  currentUser: User | null;
  selectedUserId: string | null;
  selectedArticleId: string | null;
  selectedPoemId: string | null;
  selectedStoryId: string | null;
  selectedChatId: string | null;
  selectedLiteratureType: 'article' | 'poem' | 'story';
  videos: VideoPost[];
  articles: Article[];
  poems: Poem[];
  stories: ShortStory[];
  conversations: ChatConversation[];
  notifications: Notification[];
  showComments: boolean;
  showShare: boolean;
  showCreateOptions: boolean;
  toast: { message: string; visible: boolean } | null;
  authLoading: boolean;
}

type Action =
  | { type: 'NAVIGATE'; screen: Screen }
  | { type: 'GO_BACK' }
  | { type: 'SET_TAB'; tab: Tab }
  | { type: 'LOGIN'; user: User }
  | { type: 'LOGOUT' }
  | { type: 'SET_SELECTED_USER'; userId: string }
  | { type: 'SET_SELECTED_ARTICLE'; articleId: string }
  | { type: 'SET_SELECTED_POEM'; poemId: string }
  | { type: 'SET_SELECTED_STORY'; storyId: string }
  | { type: 'SET_SELECTED_CHAT'; chatId: string }
  | { type: 'SET_LITERATURE_TYPE'; litType: 'article' | 'poem' | 'story' }
  | { type: 'TOGGLE_LIKE_VIDEO'; videoId: string }
  | { type: 'TOGGLE_BOOKMARK_VIDEO'; videoId: string }
  | { type: 'TOGGLE_LIKE_ARTICLE'; articleId: string }
  | { type: 'TOGGLE_BOOKMARK_ARTICLE'; articleId: string }
  | { type: 'TOGGLE_LIKE_POEM'; poemId: string }
  | { type: 'TOGGLE_BOOKMARK_POEM'; poemId: string }
  | { type: 'TOGGLE_LIKE_STORY'; storyId: string }
  | { type: 'TOGGLE_BOOKMARK_STORY'; storyId: string }
  | { type: 'TOGGLE_FOLLOW'; userId: string }
  | { type: 'SET_SHOW_COMMENTS'; show: boolean }
  | { type: 'SET_SHOW_SHARE'; show: boolean }
  | { type: 'SET_SHOW_CREATE'; show: boolean }
  | { type: 'SHOW_TOAST'; message: string }
  | { type: 'HIDE_TOAST' }
  | { type: 'UPDATE_PROFILE'; user: Partial<User> }
  | { type: 'SET_CONVERSATIONS'; conversations: ChatConversation[] }
  | { type: 'RECEIVE_MESSAGE'; chatId: string; message: ChatMessage }
  | { type: 'APPEND_LOCAL_MESSAGE'; chatId: string; message: ChatMessage }
  | { type: 'SET_AUTH_LOADING'; loading: boolean }
  | { type: 'ADD_LITERATURE'; item: Article | Poem | ShortStory }
  | { type: 'READ_NOTIFICATION'; notifId: string };

const tabScreenMap: Record<Tab, Screen> = {
  home: 'videoFeed',
  explore: 'explore',
  create: 'create',
  literature: 'literature',
  profile: 'profile',
};

const defaultUser: User = {
  id: 'current-user',
  username: 'sastrawan',
  displayName: 'Sastrawan Muda',
  bio: 'Penyair, penulis, dan pembaca buku 📚✨',
  avatar: '',
  followers: 12400,
  following: 890,
  likes: 45600,
};

const demoUsers: User[] = [
  { id: 'u1', username: 'sastrawan', displayName: 'Sastrawan', bio: 'Penyair dan penulis', avatar: '', followers: 45200, following: 320, likes: 128000 },
  { id: 'u2', username: 'penabaru', displayName: 'Pena Baru', bio: 'Aspiring writer ✍️', avatar: '', followers: 23100, following: 540, likes: 67000 },
  { id: 'u3', username: 'budayawan', displayName: 'Budayawan', bio: 'Melestarikan budaya Nusantara', avatar: '', followers: 67800, following: 120, likes: 234000 },
  { id: 'u4', username: 'booklover', displayName: 'Book Lover', bio: 'Reading is living 📖', avatar: '', followers: 89200, following: 780, likes: 345000 },
  { id: 'u5', username: 'komunitas_menulis', displayName: 'Komunitas Menulis', bio: 'Komunitas penulis Indonesia', avatar: '', followers: 156000, following: 45, likes: 567000 },
  { id: 'u6', username: 'jurnalis_muda', displayName: 'Jurnalis Muda', bio: 'Journalist | Storyteller', avatar: '', followers: 34500, following: 670, likes: 89000 },
  { id: 'u7', username: 'puisiku', displayName: 'Puisi Ku', bio: 'Coretan puisi sehari-hari', avatar: '', followers: 198000, following: 230, likes: 890000 },
  { id: 'u8', username: 'gurucreative', displayName: 'Guru Creative', bio: 'Guru yang suka menulis', avatar: '', followers: 12300, following: 450, likes: 45000 },
  { id: 'u9', username: 'event_literasi', displayName: 'Event Literasi', bio: 'Info event sastra & literasi', avatar: '', followers: 67000, following: 180, likes: 123000 },
  { id: 'u10', username: 'malampuisi', displayName: 'Malam Puisi', bio: 'Puisi malam yang sunyi 🌙', avatar: '', followers: 234000, following: 120, likes: 1200000 },
];

const initialState: AppState = {
  screen: 'login',
  prevScreen: null,
  activeTab: 'home',
  isAuthenticated: false,
  currentUser: null,
  selectedUserId: null,
  selectedArticleId: null,
  selectedPoemId: null,
  selectedStoryId: null,
  selectedChatId: null,
  selectedLiteratureType: 'article',
  videos: [
    { id: 'v1', user: demoUsers[0], caption: 'Senja di Pelabuhan — puisi karya Chairil Anwar. Suara: @sastrawan', thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&h=800&fit=crop', likes: 12500, comments: 342, shares: 89, bookmarked: false, liked: false, music: 'original sound - sastrawan' },
    { id: 'v2', user: demoUsers[1], caption: '3 teknik menulis cerpen yang wajib dicoba penula! 📝 #menulis #cerpen #tutorial', thumbnail: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=800&fit=crop', likes: 45200, comments: 1200, shares: 567, bookmarked: false, liked: false, music: 'Upbeat Academic - penabaru' },
    { id: 'v3', user: demoUsers[2], caption: 'Puisi rakyat dari Nusantara yang jarang diketahui 📖 #puisi #budaya #nusantara', thumbnail: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=600&h=800&fit=crop', likes: 28900, comments: 876, shares: 234, bookmarked: false, liked: false, music: 'Gamelan Modern - budayawan' },
    { id: 'v4', user: demoUsers[3], caption: 'Review buku Laut Bercerita karya Leila S. Chudori. Spoiler-free! 📚', thumbnail: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600&h=800&fit=crop', likes: 67300, comments: 2100, shares: 890, bookmarked: false, liked: false, music: 'Chill Vibes - booklover' },
    { id: 'v5', user: demoUsers[4], caption: 'Sesi live menulis cerpen bersama! Yuk join 🖊️', thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=800&fit=crop', likes: 5200, comments: 123, shares: 45, bookmarked: false, liked: false, music: 'Live - komunitas_menulis', isLive: true, viewers: 1200 },
    { id: 'v6', user: demoUsers[5], caption: 'Cara menulis artikel yang menarik perhatian pembaca ✍️ #jurnalistik #artikel', thumbnail: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=600&h=800&fit=crop', likes: 33100, comments: 654, shares: 321, bookmarked: false, liked: false, music: 'Inspiring - jurnalis_muda' },
    { id: 'v7', user: demoUsers[6], caption: 'Untukmu yang di sana. Puisi original ✨ #puisi #cinta #original', thumbnail: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=600&h=800&fit=crop', likes: 89400, comments: 3400, shares: 1200, bookmarked: false, liked: false, music: 'Akustik Romantis - puisiku' },
    { id: 'v8', user: demoUsers[7], caption: 'Cerpen anak-anak karya murid kelas 5 SD. Lucu dan mengharukan! 👧👦', thumbnail: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&h=800&fit=crop', likes: 15700, comments: 432, shares: 156, bookmarked: false, liked: false, music: 'Ceria - gurucreative' },
    { id: 'v9', user: demoUsers[8], caption: 'Cuplikan workshop literasi nasional 2024 📚 #workshop #literasi #2024', thumbnail: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=800&fit=crop', likes: 5200, comments: 123, shares: 45, bookmarked: false, liked: false, music: 'Event BGM - event_literasi' },
    { id: 'v10', user: demoUsers[9], caption: 'Malam ini aku menulis untukmu yang tak pernah datang 🌙 #puisi #malam #sendu', thumbnail: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600&h=800&fit=crop', likes: 156000, comments: 5600, shares: 2300, bookmarked: false, liked: false, music: 'Piano Sendu - malampuisi' },
  ],
  articles: [
    { id: 'a1', title: 'Mengapa Literasi Digital Penting di Era AI', excerpt: 'Di era kecerdasan buatan yang berkembang pesat, kemampuan memahami dan menavigasi informasi digital menjadi keterampilan vital...', content: 'Di era kecerdasan buatan yang berkembang pesat, kemampuan memahami dan menavigasi informasi digital menjadi keterampilan vital yang harus dimiliki setiap individu. Literasi digital bukan lagi sekadar kemampuan mengoperasikan perangkat teknologi, melainkan sebuah kompetensi komprehensif yang mencakup kemampuan mencari, mengevaluasi, memanfaatkan, dan menciptakan informasi secara digital dengan bijak dan bertanggung jawab.', author: demoUsers[5], thumbnail: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=600&h=340&fit=crop', category: 'Pendidikan', readTime: '5 menit', readCount: 12300, likes: 2340, comments: 156, publishedAt: '2 hari lalu', bookmarked: false, liked: false },
    { id: 'a2', title: 'Sejarah Perkembangan Cerpen Indonesia', excerpt: 'Cerpen di Indonesia memiliki sejarah panjang yang dimulai dari era kolonial hingga perkembangan digital saat ini...', content: 'Cerpen di Indonesia memiliki sejarah panjang yang dimulai dari era kolonial hingga perkembangan digital saat ini. Dari karya-karya awal yang terinspirasi oleh sastra Melayu hingga inovasi format modern, cerpen Indonesia telah mengalami transformasi yang signifikan.', author: demoUsers[0], thumbnail: 'https://images.unsplash.com/photo-1463320726281-696a485928c7?w=600&h=340&fit=crop', category: 'Budaya', readTime: '8 menit', readCount: 8700, likes: 1890, comments: 234, publishedAt: '5 hari lalu', bookmarked: false, liked: false },
    { id: 'a3', title: 'Teknik Menulis Puisi Bebas yang Menyentuh', excerpt: 'Puisi bebas memberikan keleluasaan dalam berekspresi. Pelajari teknik-teknik dasar yang akan membuat puisimu lebih berdaya...', content: 'Puisi bebas memberikan keleluasaan dalam berekspresi tanpa terikat oleh aturan rima dan meter yang kaku. Namun, kebebasan ini bukan berarti tanpa teknik. Sebaliknya, penulis puisi bebas harus menguasai teknik-teknik yang lebih halus untuk menciptakan karya yang bermakna dan menyentuh.', author: demoUsers[6], thumbnail: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=340&fit=crop', category: 'Pendidikan', readTime: '6 menit', readCount: 15200, likes: 3450, comments: 289, publishedAt: '1 minggu lalu', bookmarked: false, liked: false },
    { id: 'a4', title: 'Dampak Media Sosial terhadap Kebiasaan Membaca', excerpt: 'Bagaimana media sosial mengubah cara kita membaca dan mengonsumsi informasi di era digital...', content: 'Media sosial telah mengubah lanskap literasi secara fundamental. Dengan karakter konten yang singkat dan cepat, platform seperti TikTok, Instagram, dan Twitter telah membentuk ulang cara kita mengonsumsi informasi dan literatur.', author: demoUsers[3], thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=340&fit=crop', category: 'Sosial', readTime: '7 menit', readCount: 9100, likes: 2100, comments: 178, publishedAt: '3 hari lalu', bookmarked: false, liked: false },
    { id: 'a5', title: 'Mengenal Sastra Lisan Nusantara', excerpt: 'Dari pantun hingga gurindam, warisan sastra lisan Nusantara merupakan kekayaan budaya yang tak ternilai...', content: 'Nusantara memiliki warisan sastra lisan yang kaya dan beragam. Dari pantun Melayu hingga gurindam Minang, dari tembang Jawa hingka dongeng Toraja, setiap daerah memiliki tradisi sastra lisan yang unik dan mempesona.', author: demoUsers[2], thumbnail: 'https://images.unsplash.com/photo-1523527921736-473bb519a167?w=600&h=340&fit=crop', category: 'Budaya', readTime: '10 menit', readCount: 6400, likes: 1670, comments: 198, publishedAt: '1 minggu lalu', bookmarked: false, liked: false },
  ],
  poems: [
    { id: 'p1', title: 'Hujan di Bulan Juni', content: 'Kau datang dan pergi bagai hujan di bulan Juni\nTak terduga, tak diundang, namun selalu dinanti\nBasahi jalan yang kering ini\nDengan cerita-cerita yang kau bawa\n\nDi bawah payung yang sama\nKita berbagi tawa dan sunyi\nHingga tetes terakhir mengering\nDan kau pergi, seperti datangnya', author: demoUsers[6], likes: 8900, comments: 456, publishedAt: '2 hari lalu', bookmarked: false, liked: false },
    { id: 'p2', title: 'Surat untuk Ibu', content: 'Ibu, maafkan aku yang sering lupa menelepon\nYang terlalu sibuk mengejar mimpi\nSampai lupa bahwa rumah ada di sana\nMenunggu dengan senyum dan masakan hangat\n\nDi setiap langkah yang kutapaki\nAda doa yang kau panjatkan\nDi setiap jatuh dan bangun\nAda pelukan yang selalu kau siapkan\n\nIbu, aku menulis ini untukmu\nYang tak pernah minta balasan\nHanya ingin kau tahu\nAku selalu membawamu dalam perjalanan', author: demoUsers[1], likes: 12300, comments: 678, publishedAt: '3 hari lalu', bookmarked: false, liked: false },
    { id: 'p3', title: 'Kota Kita', content: 'Di sudut warung kopi yang sama\nKita bertemu setiap pagi\nPembicaraan tentang cuaca dan mimpi\nYang tak pernah usai\n\nDi trotoar yang retak\nKita berjalan beriringan\nMelewati cerita kota\nYang tak pernah tidur\n\nKota ini terlalu besar untuk sendiri\nDan terlalu kecil tanpamu', author: demoUsers[0], likes: 6700, comments: 234, publishedAt: '5 hari lalu', bookmarked: false, liked: false },
    { id: 'p4', title: 'Malam Tanpamu', content: 'Jam dinding berdetak lebih lambat malam ini\nAngin sepoi-sepoi bawa bau kenangan\nYang kau tinggal di bantal sebelah\n\nAku menulis namamu di kaca berembun\nLalu menghapusnya dengan siku\nSeperti yang kau lakukan pada hatiku\n\nMalam ini terlalu panjang\nDan aku terlalu sendiri\nUntuk tidur sendirian lagi', author: demoUsers[9], likes: 15600, comments: 890, publishedAt: '1 hari lalu', bookmarked: false, liked: false },
    { id: 'p5', title: 'Pagi di Kampungku', content: 'Ayam jantan berkokok di ufuk timur\nIbu menyiapkan sarapan di dapur\nAsap mengepul dari cerobong\nMenyambut mentari yang baru bangun\n\nAnak-anak berlari di sawah hijau\nBawa layang-layang dari kertas koran\nTawa mereka menggema\nLebih merdu dari burung murai\n\nKampungku, tempat hatiku pulang\nSetiap kali dunia terlalu ramai', author: demoUsers[2], likes: 9200, comments: 345, publishedAt: '4 hari lalu', bookmarked: false, liked: false },
  ],
  stories: [
    { id: 's1', title: 'The Last Letter', excerpt: 'Sebuah surat misterius yang mengubah segalanya...', content: 'Sebuah surat misterius yang mengubah segalanya datang pada hari Selasa yang hujan. Aria membuka amplop kuning itu dengan tangan gemetar. Surat dari seseorang yang sudah lima tahun hilang...', author: demoUsers[1], thumbnail: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=600&h=340&fit=crop', genre: 'Thriller/Misteri', chapters: 15, rating: 4.8, likes: 8900, comments: 567, publishedAt: '2 minggu lalu', bookmarked: false, liked: false },
    { id: 's2', title: 'Kopi dan Kenangan', excerpt: 'Setiap cangkir kopi punya cerita...', content: 'Setiap cangkir kopi punya cerita. Di kedai tua di pojok jalan, Raka menemukan buku harian yang tertinggal di meja nomor tujuh. Isinya adalah cerita cinta yang belum selesai ditulis...', author: demoUsers[0], thumbnail: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=340&fit=crop', genre: 'Romansa', chapters: 8, rating: 4.9, likes: 12300, comments: 890, publishedAt: '1 minggu lalu', bookmarked: false, liked: false },
    { id: 's3', title: 'Si Kecil dan Bintang', excerpt: 'Petualangan mencari bintang jatuh...', content: 'Nina adalah anak berusia tujuh tahun yang percaya bahwa setiap bintang jatuh adalah permintaan yang dikabulkan. Suatu malam, dia melihat yang paling terang dan memutuskan untuk mengejarnya...', author: demoUsers[7], thumbnail: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600&h=340&fit=crop', genre: 'Anak-anak', chapters: 5, rating: 4.7, likes: 5600, comments: 234, publishedAt: '3 hari lalu', bookmarked: false, liked: false },
    { id: 's4', title: 'Gadis Penjual Koran', excerpt: 'Kisah perjuangan di tengah kota besar...', content: 'Siti berusia dua belas tahun ketika ayahnya jatuh sakit. Setiap pagi, dia berjalan lima kilometer menjual koran di persimpangan jalan. Tapi Siti punya mimpi yang lebih besar dari kemiskinan...', author: demoUsers[5], thumbnail: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=600&h=340&fit=crop', genre: 'Drama', chapters: 12, rating: 4.6, likes: 7800, comments: 456, publishedAt: '5 hari lalu', bookmarked: false, liked: false },
    { id: 's5', title: 'Taman Bermain Tua', excerpt: 'Jangan main sendirian di sana setelah gelap...', content: 'Taman bermain tua di ujung komplek sudah ditutup selama sepuluh tahun. Tapi setiap malam Jumat, ayunan itu bergerak sendiri. Anak-anak bilang ada seorang gadis kecil yang masih menunggu temannya...', author: demoUsers[9], thumbnail: 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?w=600&h=340&fit=crop', genre: 'Horor', chapters: 10, rating: 4.5, likes: 10200, comments: 678, publishedAt: '1 minggu lalu', bookmarked: false, liked: false },
  ],
  conversations: [] as ChatConversation[],
  notifications: [
    { id: 'n1', type: 'like', user: demoUsers[1], message: 'menyukai video Anda', timestamp: '2 menit lalu', read: false },
    { id: 'n2', type: 'comment', user: demoUsers[2], message: 'mengomentari puisi Anda: "Indah banget!"', timestamp: '15 menit lalu', read: false },
    { id: 'n3', type: 'follow', user: demoUsers[3], message: 'mulai mengikuti Anda', timestamp: '1 jam lalu', read: false },
    { id: 'n4', type: 'like', user: demoUsers[0], message: 'menyukai artikel Anda', timestamp: '3 jam lalu', read: true },
    { id: 'n5', type: 'system', message: 'Selamat! Akun Anda telah terverifikasi.', timestamp: '1 hari lalu', read: true },
    { id: 'n6', type: 'mention', user: demoUsers[5], message: 'menyebut Anda dalam komentar', timestamp: '2 hari lalu', read: true },
  ],
  showComments: false,
  showShare: false,
  showCreateOptions: false,
  toast: null,
  authLoading: true,
};

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'NAVIGATE':
      return { ...state, prevScreen: state.screen, screen: action.screen };
    case 'GO_BACK':
      return {
        ...state,
        screen: state.prevScreen ?? (state.isAuthenticated ? tabScreenMap[state.activeTab] : 'login'),
        prevScreen: null,
      };
    case 'SET_TAB': {
      const screen = tabScreenMap[action.tab];
      return { ...state, activeTab: action.tab, prevScreen: state.screen, screen };
    }
    case 'LOGIN':
      return { ...state, isAuthenticated: true, currentUser: action.user, screen: 'videoFeed', activeTab: 'home', authLoading: false };
    case 'LOGOUT':
      return { ...initialState, videos: state.videos, articles: state.articles, poems: state.poems, stories: state.stories, authLoading: false, screen: 'login' };
    case 'SET_AUTH_LOADING':
      return { ...state, authLoading: action.loading };
    case 'SET_CONVERSATIONS':
      return { ...state, conversations: action.conversations };
    case 'RECEIVE_MESSAGE': {
      return {
        ...state,
        conversations: state.conversations.map(c => {
          if (c.id !== action.chatId) return c;
          if (c.messages.some(m => m.id === action.message.id)) return c;

          // Jika pesan ini dari diri sendiri, kemungkinan ada pesan optimistic
          // (id sementara) yang perlu digantikan agar tidak dobel.
          const tempIndex = c.messages.findIndex(
            m => m.id.startsWith('temp-') && m.senderId === action.message.senderId
          );
          const messages = tempIndex !== -1
            ? c.messages.map((m, i) => (i === tempIndex ? action.message : m))
            : [...c.messages, action.message];

          return {
            ...c,
            messages,
            lastMessage: action.message.imageUrl ? '📷 Gambar' : action.message.content,
            timestamp: action.message.timestamp,
          };
        }),
      };
    }
    case 'APPEND_LOCAL_MESSAGE': {
      return {
        ...state,
        conversations: state.conversations.map(c =>
          c.id === action.chatId
            ? {
                ...c,
                messages: [...c.messages, action.message],
                lastMessage: action.message.imageUrl ? '📷 Gambar' : action.message.content,
                timestamp: action.message.timestamp,
              }
            : c
        ),
      };
    }
    case 'SET_SELECTED_USER':
      return { ...state, selectedUserId: action.userId, prevScreen: state.screen, screen: 'userProfile' };
    case 'SET_SELECTED_ARTICLE':
      return { ...state, selectedArticleId: action.articleId, prevScreen: state.screen, screen: 'articleDetail' };
    case 'SET_SELECTED_POEM':
      return { ...state, selectedPoemId: action.poemId, prevScreen: state.screen, screen: 'poemDetail' };
    case 'SET_SELECTED_STORY':
      return { ...state, selectedStoryId: action.storyId, prevScreen: state.screen, screen: 'storyDetail' };
    case 'SET_SELECTED_CHAT':
      return { ...state, selectedChatId: action.chatId, prevScreen: state.screen, screen: 'chatDetail' };
    case 'SET_LITERATURE_TYPE':
      return { ...state, selectedLiteratureType: action.litType };
    case 'TOGGLE_LIKE_VIDEO':
      return {
        ...state,
        videos: state.videos.map(v =>
          v.id === action.videoId ? { ...v, liked: !v.liked, likes: v.liked ? v.likes - 1 : v.likes + 1 } : v
        ),
      };
    case 'TOGGLE_BOOKMARK_VIDEO':
      return {
        ...state,
        videos: state.videos.map(v =>
          v.id === action.videoId ? { ...v, bookmarked: !v.bookmarked } : v
        ),
      };
    case 'TOGGLE_LIKE_ARTICLE':
      return {
        ...state,
        articles: state.articles.map(a =>
          a.id === action.articleId ? { ...a, liked: !a.liked, likes: a.liked ? a.likes - 1 : a.likes + 1 } : a
        ),
      };
    case 'TOGGLE_BOOKMARK_ARTICLE':
      return {
        ...state,
        articles: state.articles.map(a =>
          a.id === action.articleId ? { ...a, bookmarked: !a.bookmarked } : a
        ),
      };
    case 'TOGGLE_LIKE_POEM':
      return {
        ...state,
        poems: state.poems.map(p =>
          p.id === action.poemId ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 } : p
        ),
      };
    case 'TOGGLE_BOOKMARK_POEM':
      return {
        ...state,
        poems: state.poems.map(p =>
          p.id === action.poemId ? { ...p, bookmarked: !p.bookmarked } : p
        ),
      };
    case 'TOGGLE_LIKE_STORY':
      return {
        ...state,
        stories: state.stories.map(s =>
          s.id === action.storyId ? { ...s, liked: !s.liked, likes: s.liked ? s.likes - 1 : s.likes + 1 } : s
        ),
      };
    case 'TOGGLE_BOOKMARK_STORY':
      return {
        ...state,
        stories: state.stories.map(s =>
          s.id === action.storyId ? { ...s, bookmarked: !s.bookmarked } : s
        ),
      };
    case 'TOGGLE_FOLLOW': {
      const users = [defaultUser, ...demoUsers];
      const user = users.find(u => u.id === action.userId);
      if (!user) return state;
      const isFollowing = !user.isFollowing;
      const updatedUser = users.find(u => u.id === action.userId);
      if (updatedUser) {
        updatedUser.isFollowing = isFollowing;
        updatedUser.followers = isFollowing ? updatedUser.followers + 1 : updatedUser.followers - 1;
      }
      return { ...state };
    }
    case 'SET_SHOW_COMMENTS':
      return { ...state, showComments: action.show };
    case 'SET_SHOW_SHARE':
      return { ...state, showShare: action.show };
    case 'SET_SHOW_CREATE':
      return { ...state, showCreateOptions: action.show };
    case 'SHOW_TOAST':
      return { ...state, toast: { message: action.message, visible: true } };
    case 'HIDE_TOAST':
      return { ...state, toast: null };
    case 'UPDATE_PROFILE':
      return state.currentUser ? { ...state, currentUser: { ...state.currentUser, ...action.user } } : state;
    case 'ADD_LITERATURE': {
      if ('excerpt' in action.item && 'thumbnail' in action.item && 'readTime' in action.item) {
        return { ...state, articles: [action.item as Article, ...state.articles] };
      } else if ('content' in action.item && !('thumbnail' in action.item) && !('excerpt' in action.item)) {
        return { ...state, poems: [action.item as Poem, ...state.poems] };
      } else {
        return { ...state, stories: [action.item as ShortStory, ...state.stories] };
      }
    }
    case 'READ_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.map(n =>
          n.id === action.notifId ? { ...n, read: true } : n
        ),
      };
    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  useEffect(() => {
    let active = true;

    async function bootstrap() {
      try {
        const session = await getCurrentSession();
        if (!active) return;

        if (session?.user) {
          const profile = await getProfile(session.user.id);
          if (!active) return;
          if (profile) {
            dispatch({
              type: 'LOGIN',
              user: {
                id: profile.id,
                username: profile.username,
                displayName: profile.displayName,
                bio: profile.bio,
                avatar: profile.avatarUrl ?? '',
                followers: 0,
                following: 0,
                likes: 0,
              },
            });
            const conversations = await fetchConversations(profile.id);
            if (!active) return;
            dispatch({ type: 'SET_CONVERSATIONS', conversations });
          } else {
            dispatch({ type: 'SET_AUTH_LOADING', loading: false });
          }
        } else {
          dispatch({ type: 'SET_AUTH_LOADING', loading: false });
        }
      } catch (err) {
        console.error('Auth bootstrap error:', err);
        dispatch({ type: 'SET_AUTH_LOADING', loading: false });
      }
    }

    bootstrap();

    const subscription = onAuthStateChange((userId) => {
      if (!userId) {
        dispatch({ type: 'LOGOUT' });
      }
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
