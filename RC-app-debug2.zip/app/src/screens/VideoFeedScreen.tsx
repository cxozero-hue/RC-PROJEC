import { useState, useRef, useCallback } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, MoreVertical, Search, Music, UserPlus } from 'lucide-react';
import { useApp } from '@/context/AppContext';

function formatCount(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

export default function VideoFeedScreen() {
  const { state, dispatch } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showCommentsSheet, setShowCommentsSheet] = useState(false);
  const [showShareSheet, setShowShareSheet] = useState(false);
  const [heartAnim, setHeartAnim] = useState<{ x: number; y: number; id: number } | null>(null);
  const touchStartY = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const videos = state.videos;
  const currentVideo = videos[currentIndex];

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  }, []);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    const diff = touchStartY.current - e.changedTouches[0].clientY;
    if (Math.abs(diff) > 60) {
      if (diff > 0 && currentIndex < videos.length - 1) {
        setCurrentIndex(prev => prev + 1);
      } else if (diff < 0 && currentIndex > 0) {
        setCurrentIndex(prev => prev - 1);
      }
    }
  }, [currentIndex, videos.length]);

  const handleDoubleTap = useCallback((e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setHeartAnim({ x, y, id: Date.now() });
    if (currentVideo && !currentVideo.liked) {
      dispatch({ type: 'TOGGLE_LIKE_VIDEO', videoId: currentVideo.id });
    }
    setTimeout(() => setHeartAnim(null), 800);
  }, [currentVideo, dispatch]);

  const handleTap = useCallback(() => {
    // Toggle play/pause would go here - for now just visual
  }, []);

  if (!currentVideo) return null;

  return (
    <div className="h-full relative bg-black">
      {/* Video Container */}
      <div
        ref={containerRef}
        className="h-full w-full relative"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        onDoubleClick={handleDoubleTap}
        onClick={handleTap}
      >
        {/* Video Image */}
        <img
          src={currentVideo.thumbnail}
          alt=""
          className="w-full h-full object-cover"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />

        {/* Top Header */}
        <div className="absolute top-0 left-0 right-0 pt-11 px-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <img src="/logo.jpg" alt="" className="w-7 h-7 rounded-lg object-cover" />
            <div className="flex bg-white/15 backdrop-blur-sm rounded-full p-0.5">
              <button className="px-3 py-1 rounded-full text-white/70 text-xs font-medium">Mengikuti</button>
              <button className="px-3 py-1 rounded-full bg-white text-black text-xs font-semibold">Untuk Anda</button>
              <button className="px-3 py-1 rounded-full text-white/70 text-xs font-medium">Live</button>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button className="w-10 h-10 flex items-center justify-center">
              <Search className="w-5 h-5 text-white" />
            </button>
            <button
              onClick={() => dispatch({ type: 'NAVIGATE', screen: 'chatList' })}
              className="w-10 h-10 flex items-center justify-center relative"
            >
              <MessageCircle className="w-5 h-5 text-white" />
              {state.conversations.reduce((sum, c) => sum + c.unread, 0) > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
              )}
            </button>
          </div>
        </div>

        {/* Story Rings Bar */}
        <div className="absolute top-[72px] left-0 right-0 flex gap-3 px-4 overflow-x-auto no-scrollbar z-10">
          <button className="flex flex-col items-center gap-1 shrink-0">
            <div className="w-14 h-14 rounded-full border-2 border-dashed border-amber-400 flex items-center justify-center bg-white/10 backdrop-blur-sm">
              <UserPlus className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-white text-[10px]">Tambah</span>
          </button>
          {videos.slice(0, 6).map((v, i) => (
            <button key={v.id} className="flex flex-col items-center gap-1 shrink-0" onClick={() => setCurrentIndex(i)}>
              <div className={`w-14 h-14 rounded-full p-[2px] ${i === currentIndex ? 'bg-gradient-to-tr from-amber-400 to-amber-600' : 'bg-gray-600'}`}>
                <div className="w-full h-full rounded-full bg-gray-700 flex items-center justify-center overflow-hidden">
                  <span className="text-white text-xs font-bold">{v.user.displayName[0]}</span>
                </div>
              </div>
              <span className="text-white text-[10px] max-w-[56px] truncate">{v.user.displayName}</span>
            </button>
          ))}
        </div>

        {/* Right Side Actions */}
        <div className="absolute right-3 bottom-28 flex flex-col items-center gap-5 z-10">
          {/* Avatar */}
          <button className="relative" onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: currentVideo.user.id })}>
            <div className="w-11 h-11 rounded-full bg-gray-700 flex items-center justify-center overflow-hidden border border-white/30">
              <span className="text-white text-sm font-bold">{currentVideo.user.displayName[0]}</span>
            </div>
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center border-2 border-black">
              <span className="text-white text-[8px] font-bold">+</span>
            </div>
          </button>

          {/* Like */}
          <button className="flex flex-col items-center gap-0.5" onClick={() => dispatch({ type: 'TOGGLE_LIKE_VIDEO', videoId: currentVideo.id })}>
            <Heart className={`w-7 h-7 text-shadow ${currentVideo.liked ? 'text-red-500 fill-red-500' : 'text-white'}`} />
            <span className="text-white text-[11px] font-medium text-shadow">{formatCount(currentVideo.likes)}</span>
          </button>

          {/* Comments */}
          <button className="flex flex-col items-center gap-0.5" onClick={() => setShowCommentsSheet(true)}>
            <MessageCircle className="w-7 h-7 text-white text-shadow" />
            <span className="text-white text-[11px] font-medium text-shadow">{formatCount(currentVideo.comments)}</span>
          </button>

          {/* Bookmark */}
          <button className="flex flex-col items-center gap-0.5" onClick={() => dispatch({ type: 'TOGGLE_BOOKMARK_VIDEO', videoId: currentVideo.id })}>
            <Bookmark className={`w-7 h-7 text-shadow ${currentVideo.bookmarked ? 'text-amber-400 fill-amber-400' : 'text-white'}`} />
          </button>

          {/* Share */}
          <button className="flex flex-col items-center gap-0.5" onClick={() => setShowShareSheet(true)}>
            <Share2 className="w-7 h-7 text-white text-shadow" />
            <span className="text-white text-[11px] font-medium text-shadow">{formatCount(currentVideo.shares)}</span>
          </button>

          {/* More */}
          <button className="flex flex-col items-center gap-0.5">
            <MoreVertical className="w-7 h-7 text-white text-shadow" />
          </button>
        </div>

        {/* Bottom Info */}
        <div className="absolute left-4 right-16 bottom-24 z-10">
          {currentVideo.isLive && (
            <div className="flex items-center gap-1.5 mb-2">
              <div className="flex items-center gap-1.5 bg-red-600 px-2.5 py-0.5 rounded-md">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse-live" />
                <span className="text-white text-xs font-bold">LIVE</span>
              </div>
              <span className="text-white/80 text-xs">{formatCount(currentVideo.viewers || 0)} penonton</span>
            </div>
          )}
          <button
            className="text-white font-semibold text-[15px] text-shadow"
            onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: currentVideo.user.id })}
          >
            @{currentVideo.user.username}
          </button>
          <p className="text-white text-sm text-shadow mt-1 line-clamp-2 leading-relaxed">{currentVideo.caption}</p>
          {currentVideo.music && (
            <div className="flex items-center gap-2 mt-2">
              <Music className="w-4 h-4 text-white" />
              <div className="overflow-hidden flex-1">
                <p className="text-white text-xs text-shadow whitespace-nowrap animate-marquee">{currentVideo.music}</p>
              </div>
            </div>
          )}
        </div>

        {/* Double Tap Heart Animation */}
        {heartAnim && (
          <div
            className="absolute z-20 pointer-events-none animate-floatHeart"
            style={{ left: heartAnim.x - 20, top: heartAnim.y - 20 }}
          >
            <Heart className="w-10 h-10 text-red-500 fill-red-500" />
          </div>
        )}
      </div>

      {/* Comments Bottom Sheet */}
      {showCommentsSheet && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCommentsSheet(false)} />
          <div className="relative bg-white rounded-t-2xl max-h-[60%] flex flex-col animate-slideUp">
            <div className="flex items-center justify-center py-3 border-b">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <h3 className="font-semibold text-center text-sm">{formatCount(currentVideo.comments)} Komentar</h3>
              {[
                { user: 'Ahmad', text: 'Puisinya menyentuh banget! 😭', time: '2m', likes: 24 },
                { user: 'Bella', text: 'Suka banget sama videonya', time: '5m', likes: 12 },
                { user: 'Citra', text: 'Next bikin puisi tentang pagi dong!', time: '10m', likes: 8 },
                { user: 'Dedi', text: 'Keren, lanjutkan karya-karyanya!', time: '15m', likes: 5 },
                { user: 'Eka', text: 'Ini yang aku cari selama ini', time: '20m', likes: 3 },
              ].map((c, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                    <span className="text-xs font-bold">{c.user[0]}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="font-semibold text-sm">{c.user}</span>
                      <span className="text-gray-400 text-xs">{c.time}</span>
                    </div>
                    <p className="text-sm text-gray-700 mt-0.5">{c.text}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <button className="flex items-center gap-1 text-gray-400 text-xs">
                        <Heart className="w-3.5 h-3.5" />
                        {c.likes}
                      </button>
                      <button className="text-gray-400 text-xs">Balas</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t p-3 flex gap-2">
              <input
                type="text"
                placeholder="Tambah komentar..."
                className="flex-1 h-10 bg-gray-100 rounded-full px-4 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
              <button className="text-amber-600 font-semibold text-sm">Kirim</button>
            </div>
          </div>
        </div>
      )}

      {/* Share Bottom Sheet */}
      {showShareSheet && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowShareSheet(false)} />
          <div className="relative bg-white rounded-t-2xl animate-slideUp">
            <div className="flex items-center justify-center py-3">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>
            <div className="p-6">
              <h3 className="font-semibold text-center mb-4">Bagikan ke</h3>
              <div className="grid grid-cols-4 gap-4">
                {['Salin Tautan', 'WhatsApp', 'Instagram', 'Facebook', 'Twitter', 'Email', 'SMS', 'Lainnya'].map((opt) => (
                  <button key={opt} className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
                      <Share2 className="w-5 h-5 text-gray-600" />
                    </div>
                    <span className="text-xs text-gray-600">{opt}</span>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowShareSheet(false)}
                className="w-full h-12 mt-6 bg-gray-100 rounded-xl text-gray-700 font-medium"
              >
                Batal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
