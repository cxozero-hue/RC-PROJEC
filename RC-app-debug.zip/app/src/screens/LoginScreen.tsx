import { useState } from 'react';
import { Eye, EyeOff, AtSign, Lock, ChevronRight, Loader2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { signIn, getProfile } from '@/lib/authService';
import { fetchConversations } from '@/lib/chatService';

export default function LoginScreen() {
  const { dispatch } = useApp();
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ userId?: string; password?: string; form?: string }>({});

  const validate = () => {
    const newErrors: { userId?: string; password?: string } = {};
    if (!userId.trim()) newErrors.userId = 'ID pengguna wajib diisi';
    if (!password) newErrors.password = 'Kata sandi wajib diisi';
    else if (password.length < 6) newErrors.password = 'Kata sandi minimal 6 karakter';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLogin = async () => {
    if (!validate()) return;
    setLoading(true);
    setErrors({});
    try {
      const { user } = await signIn(userId.trim(), password);
      if (!user) throw new Error('Login gagal');

      const profile = await getProfile(user.id);
      if (!profile) throw new Error('Profil tidak ditemukan');

      dispatch({
        type: 'LOGIN',
        user: {
          id: profile.id,
          username: profile.username,
          displayName: profile.displayName,
          bio: profile.bio,
          avatar: profile.avatarUrl ?? '',
          followers: 0,
          following: 0,
          likes: 0,
        },
      });

      const conversations = await fetchConversations(profile.id);
      dispatch({ type: 'SET_CONVERSATIONS', conversations });

      dispatch({ type: 'SHOW_TOAST', message: 'Berhasil masuk! Selamat datang di Ruang Cerita.' });
      setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Login gagal';
      const friendly = message.toLowerCase().includes('invalid')
        ? 'ID pengguna atau kata sandi salah.'
        : message;
      setErrors({ form: friendly });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col dark-gradient overflow-y-auto no-scrollbar">
      {/* Logo Section */}
      <div className="flex flex-col items-center pt-16 pb-8 animate-fadeInUp">
        <div className="w-[120px] h-[120px] rounded-3xl overflow-hidden shadow-xl shadow-amber-500/20 mb-5">
          <img src="/logo.jpg" alt="Ruang Cerita" className="w-full h-full object-cover" />
        </div>
        <h1 className="font-heading text-white text-2xl font-bold tracking-wide">Ruang Cerita</h1>
        <p className="text-gray-400 text-sm mt-1">Ruang untuk Berbagi Cerita</p>
      </div>

      {/* Login Form */}
      <div className="flex-1 px-6 pb-6 animate-fadeInUp" style={{ animationDelay: '0.15s' }}>
        <div className="space-y-4">
          {errors.form && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-2.5">
              <p className="text-red-400 text-sm">{errors.form}</p>
            </div>
          )}

          {/* ID Input */}
          <div>
            <label className="text-gray-300 text-sm font-medium mb-1.5 block">ID Pengguna</label>
            <div className="relative">
              <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                value={userId}
                onChange={e => setUserId(e.target.value)}
                placeholder="Masukkan ID Anda"
                className="w-full h-[50px] bg-white/10 border border-white/20 rounded-xl pl-11 pr-4 text-white placeholder-gray-500 text-[15px] focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
            {errors.userId && <p className="text-red-400 text-xs mt-1">{errors.userId}</p>}
          </div>

          {/* Password Input */}
          <div>
            <label className="text-gray-300 text-sm font-medium mb-1.5 block">Kata Sandi</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
                placeholder="Masukkan kata sandi"
                className="w-full h-[50px] bg-white/10 border border-white/20 rounded-xl pl-11 pr-12 text-white placeholder-gray-500 text-[15px] focus:outline-none focus:border-amber-500 transition-colors"
              />
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password}</p>}
          </div>

          {/* Remember me & Forgot password */}
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={e => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded border-gray-500 accent-amber-500"
              />
              <span className="text-gray-400 text-sm">Ingat saya</span>
            </label>
            <button className="text-amber-400 text-sm font-medium">Lupa kata sandi?</button>
          </div>

          {/* Login Button */}
          <button
            onClick={handleLogin}
            disabled={loading}
            className="w-full h-[52px] gold-gradient rounded-xl text-white font-semibold text-base shadow-lg shadow-amber-500/30 active:scale-[0.97] transition-transform flex items-center justify-center gap-2 disabled:opacity-70"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Masuk'}
          </button>

          {/* Register Button */}
          <button
            onClick={() => dispatch({ type: 'NAVIGATE', screen: 'register' })}
            className="w-full h-[48px] border border-amber-500/50 rounded-xl text-amber-400 font-medium text-sm active:scale-[0.97] transition-transform flex items-center justify-center gap-2"
          >
            Belum punya akun? Daftar
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 pb-8 text-center animate-fadeIn" style={{ animationDelay: '0.3s' }}>
        <div className="w-16 h-px bg-gray-700 mx-auto mb-4" />
        <p className="text-gray-500 text-xs">Dibuat dengan <span className="text-red-500">❤</span> oleh</p>
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', screen: 'about' })}
          className="text-amber-400 font-semibold text-sm mt-0.5 hover:text-amber-300 transition-colors"
        >
          Zero Coordinates
        </button>
        <div className="flex items-center justify-center gap-3 mt-3">
          <button className="text-gray-500 text-[11px] underline">Ketentuan Layanan</button>
          <span className="text-gray-700">|</span>
          <button className="text-gray-500 text-[11px] underline">Kebijakan Privasi</button>
          <span className="text-gray-700">|</span>
          <button className="text-gray-500 text-[11px] underline">Bantuan</button>
        </div>
        <p className="text-gray-600 text-[11px] mt-3">© 2024 Ruang Cerita. Hak Cipta Dilindungi.</p>
      </div>
    </div>
  );
}
