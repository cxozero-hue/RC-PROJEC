import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Phone, MoreVertical, Send, Image as ImageIcon, X, Loader2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { sendMessage, uploadChatImage, subscribeToConversation } from '@/lib/chatService';
import { pickImageFromGallery, isNativePlatform, ImagePickerCancelled } from '@/lib/imagePicker';
import type { ChatMessage } from '@/types';

export default function ChatDetailScreen() {
  const { state, dispatch } = useApp();
  const [input, setInput] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const conv = state.conversations.find(c => c.id === state.selectedChatId);
  const currentUserId = state.currentUser?.id;

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conv?.messages.length]);

  // Subscribe ke pesan baru secara realtime untuk percakapan ini
  useEffect(() => {
    if (!conv?.id) return;
    const unsubscribe = subscribeToConversation(conv.id, (message: ChatMessage) => {
      dispatch({ type: 'RECEIVE_MESSAGE', chatId: conv.id, message });
    });
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conv?.id]);

  if (!conv || !currentUserId) return null;

  const handlePickImage = async () => {
    if (isNativePlatform()) {
      try {
        const picked = await pickImageFromGallery();
        if (!picked) return;
        if (picked.file.size > 5 * 1024 * 1024) {
          dispatch({ type: 'SHOW_TOAST', message: 'Ukuran gambar maksimal 5MB.' });
          return;
        }
        setImageFile(picked.file);
        setImagePreview(picked.previewUrl);
      } catch (err) {
        if (err instanceof ImagePickerCancelled) return; // normal, diam saja
        const detail = err instanceof Error ? err.message : String(err);
        dispatch({ type: 'SHOW_TOAST', message: `Tidak bisa membuka galeri: ${detail}`, duration: 6000 });
      }
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      dispatch({ type: 'SHOW_TOAST', message: 'File harus berupa gambar.' });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      dispatch({ type: 'SHOW_TOAST', message: 'Ukuran gambar maksimal 5MB.' });
      return;
    }
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const clearImage = () => {
    setImageFile(null);
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSend = async () => {
    if (!input.trim() && !imageFile) return;
    if (sending) return;

    setSending(true);
    const textToSend = input.trim();
    const fileToSend = imageFile;

    // Optimistic UI: tampilkan pesan langsung sebelum konfirmasi server
    const tempId = `temp-${Date.now()}`;
    const optimisticMessage: ChatMessage = {
      id: tempId,
      senderId: currentUserId,
      content: textToSend,
      imageUrl: imagePreview,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      isRead: true,
    };
    dispatch({ type: 'APPEND_LOCAL_MESSAGE', chatId: conv.id, message: optimisticMessage });

    setInput('');
    clearImage();

    try {
      let imageUrl: string | null = null;
      if (fileToSend) {
        imageUrl = await uploadChatImage(fileToSend, currentUserId);
      }
      await sendMessage(conv.id, currentUserId, textToSend, imageUrl);
      // Pesan asli dari server akan masuk lewat realtime subscription,
      // duplikat dicegah lewat pengecekan id di reducer.
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      console.error('Gagal mengirim pesan:', err);
      dispatch({ type: 'SHOW_TOAST', message: `Gagal mengirim pesan: ${detail}`, duration: 6000 });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b bg-white z-10">
        <div className="flex items-center gap-3">
          <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
            {conv.user.avatar ? (
              <img src={conv.user.avatar} alt={conv.user.displayName} className="w-full h-full object-cover" />
            ) : (
              <span className="text-xs font-bold">{conv.user.displayName[0]}</span>
            )}
          </div>
          <div>
            <p className="font-semibold text-sm">{conv.user.displayName}</p>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
              <p className="text-green-600 text-[11px]">Online</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="w-10 h-10 flex items-center justify-center">
            <Phone className="w-5 h-5 text-gray-600" />
          </button>
          <button className="w-10 h-10 flex items-center justify-center">
            <MoreVertical className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-3">
        {conv.messages.map(msg => {
          const isMe = msg.senderId === currentUserId;
          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] rounded-2xl overflow-hidden ${
                isMe
                  ? 'bg-amber-500 text-white rounded-br-md'
                  : 'bg-gray-100 text-gray-800 rounded-bl-md'
              }`}>
                {msg.imageUrl && (
                  <img
                    src={msg.imageUrl}
                    alt="Gambar terkirim"
                    className="w-full max-h-72 object-cover"
                  />
                )}
                {(msg.content || !msg.imageUrl) && (
                  <div className="px-4 py-2.5">
                    {msg.content && <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>}
                    <p className={`text-[10px] mt-1 ${isMe ? 'text-amber-100' : 'text-gray-400'}`}>
                      {msg.timestamp}
                    </p>
                  </div>
                )}
                {msg.imageUrl && !msg.content && (
                  <p className={`text-[10px] px-2 pb-1.5 ${isMe ? 'text-amber-100' : 'text-gray-400'}`}>
                    {msg.timestamp}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Image Preview Bar */}
      {imagePreview && (
        <div className="shrink-0 border-t bg-gray-50 px-4 py-2">
          <div className="relative inline-block">
            <img src={imagePreview} alt="Preview" className="h-20 rounded-lg object-cover" />
            <button
              onClick={clearImage}
              className="absolute -top-2 -right-2 w-6 h-6 bg-gray-800 rounded-full flex items-center justify-center"
            >
              <X className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
        </div>
      )}

      {/* Input Bar */}
      <div className="shrink-0 border-t bg-white px-4 py-2 flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        <button
          onClick={handlePickImage}
          className="w-10 h-10 flex items-center justify-center shrink-0"
        >
          <ImageIcon className="w-5 h-5 text-gray-500" />
        </button>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Tulis pesan..."
          className="flex-1 h-10 bg-gray-100 rounded-full px-4 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          onClick={handleSend}
          disabled={sending || (!input.trim() && !imageFile)}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors shrink-0 ${
            (input.trim() || imageFile) ? 'bg-amber-500' : 'bg-gray-200'
          }`}
        >
          {sending ? (
            <Loader2 className="w-5 h-5 text-white animate-spin" />
          ) : (
            <Send className={`w-5 h-5 ${(input.trim() || imageFile) ? 'text-white' : 'text-gray-400'}`} />
          )}
        </button>
      </div>
    </div>
  );
}
