import { supabase } from './supabase';

export interface AuthProfile {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bio: string;
}

/**
 * Pastikan baris profile ada untuk user ini. Trigger database seharusnya
 * sudah membuat ini otomatis saat signup, tapi fungsi ini jadi pengaman
 * kalau trigger gagal jalan (misal karena urutan migrasi atau timing).
 */
async function ensureProfile(userId: string, username: string, displayName: string) {
  const { error } = await supabase
    .from('profiles')
    .upsert(
      { id: userId, username, display_name: displayName },
      { onConflict: 'id', ignoreDuplicates: true }
    );
  if (error) {
    console.error('ensureProfile error:', error.message);
  }
}

/**
 * Daftar pengguna baru. Supabase Auth butuh email, jadi kita pakai
 * format email samaran dari username jika pengguna tidak memberi email asli.
 */
export async function signUp(username: string, password: string, email?: string) {
  const finalEmail = email && email.includes('@') ? email : `${username}@ruangcerita.local`;

  const { data, error } = await supabase.auth.signUp({
    email: finalEmail,
    password,
    options: {
      data: {
        username,
        display_name: username,
      },
    },
  });

  if (error) throw error;

  if (data.user) {
    await ensureProfile(data.user.id, username, username);
  }

  return data;
}

export async function signIn(usernameOrEmail: string, password: string) {
  const email = usernameOrEmail.includes('@')
    ? usernameOrEmail
    : `${usernameOrEmail}@ruangcerita.local`;

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session;
}

export async function getProfile(userId: string): Promise<AuthProfile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, display_name, avatar_url, bio')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('getProfile error:', error.message);
    return null;
  }

  return {
    id: data.id,
    username: data.username,
    displayName: data.display_name,
    avatarUrl: data.avatar_url,
    bio: data.bio,
  };
}

export async function updateProfile(
  userId: string,
  updates: Partial<{ displayName: string; bio: string; avatarUrl: string }>
) {
  const { error } = await supabase
    .from('profiles')
    .update({
      ...(updates.displayName !== undefined && { display_name: updates.displayName }),
      ...(updates.bio !== undefined && { bio: updates.bio }),
      ...(updates.avatarUrl !== undefined && { avatar_url: updates.avatarUrl }),
    })
    .eq('id', userId);

  if (error) throw error;
}

export function onAuthStateChange(callback: (userId: string | null) => void) {
  const { data } = supabase.auth.onAuthStateChange((_event, session) => {
    callback(session?.user?.id ?? null);
  });
  return data.subscription;
}
