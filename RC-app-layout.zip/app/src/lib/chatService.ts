import { supabase } from './supabase';
import type { ChatConversation, ChatMessage, User } from '@/types';

interface ProfileRow {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string | null;
  bio: string;
}

function profileToUser(p: ProfileRow): User {
  return {
    id: p.id,
    username: p.username,
    displayName: p.display_name,
    bio: p.bio ?? '',
    avatar: p.avatar_url ?? '',
    followers: 0,
    following: 0,
    likes: 0,
  };
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}

/**
 * Ambil semua percakapan milik pengguna saat ini, lengkap dengan
 * data lawan bicara dan daftar pesan.
 */
export async function fetchConversations(currentUserId: string): Promise<ChatConversation[]> {
  const { data: participantRows, error: partError } = await supabase
    .from('conversation_participants')
    .select('conversation_id')
    .eq('user_id', currentUserId);

  if (partError) throw partError;
  const conversationIds = (participantRows ?? []).map(r => r.conversation_id);
  if (conversationIds.length === 0) return [];

  // Ambil semua peserta lain di setiap percakapan tersebut
  const { data: allParticipants, error: allPartError } = await supabase
    .from('conversation_participants')
    .select('conversation_id, user_id, profiles(id, username, display_name, avatar_url, bio)')
    .in('conversation_id', conversationIds);

  if (allPartError) throw allPartError;

  const { data: messages, error: msgError } = await supabase
    .from('messages')
    .select('id, conversation_id, sender_id, content, image_url, created_at, is_read')
    .in('conversation_id', conversationIds)
    .order('created_at', { ascending: true });

  if (msgError) throw msgError;

  const conversations: ChatConversation[] = conversationIds.map(convId => {
    const otherParticipant = (allParticipants ?? []).find(
      p => p.conversation_id === convId && p.user_id !== currentUserId
    );
    const otherProfile = otherParticipant?.profiles as unknown as ProfileRow | undefined;

    const convMessages = (messages ?? [])
      .filter(m => m.conversation_id === convId)
      .map<ChatMessage>(m => ({
        id: m.id,
        senderId: m.sender_id,
        content: m.content ?? '',
        imageUrl: m.image_url,
        timestamp: formatTime(m.created_at),
        isRead: m.is_read,
      }));

    const last = convMessages[convMessages.length - 1];

    return {
      id: convId,
      user: otherProfile
        ? profileToUser(otherProfile)
        : { id: 'unknown', username: 'unknown', displayName: 'Pengguna', bio: '', avatar: '', followers: 0, following: 0, likes: 0 },
      messages: convMessages,
      lastMessage: last ? (last.imageUrl ? '📷 Gambar' : last.content) : '',
      timestamp: last ? last.timestamp : '',
      unread: convMessages.filter(m => !m.isRead && m.senderId !== currentUserId).length,
    };
  });

  return conversations;
}

/**
 * Cari atau buat percakapan baru antara dua pengguna.
 */
export async function getOrCreateConversation(currentUserId: string, otherUserId: string): Promise<string> {
  const { data: myConvs, error: myErr } = await supabase
    .from('conversation_participants')
    .select('conversation_id')
    .eq('user_id', currentUserId);
  if (myErr) throw myErr;

  const myConvIds = (myConvs ?? []).map(r => r.conversation_id);

  if (myConvIds.length > 0) {
    const { data: shared, error: sharedErr } = await supabase
      .from('conversation_participants')
      .select('conversation_id')
      .eq('user_id', otherUserId)
      .in('conversation_id', myConvIds);
    if (sharedErr) throw sharedErr;
    if (shared && shared.length > 0) {
      return shared[0].conversation_id;
    }
  }

  const { data: newConv, error: convErr } = await supabase
    .from('conversations')
    .insert({ created_by: currentUserId })
    .select('id')
    .single();
  if (convErr) throw convErr;

  const { error: partErr } = await supabase.from('conversation_participants').insert([
    { conversation_id: newConv.id, user_id: currentUserId },
    { conversation_id: newConv.id, user_id: otherUserId },
  ]);
  if (partErr) throw partErr;

  return newConv.id;
}

/**
 * Kirim pesan teks dan/atau gambar.
 */
export async function sendMessage(
  conversationId: string,
  senderId: string,
  content: string,
  imageUrl?: string | null
) {
  const { data, error } = await supabase
    .from('messages')
    .insert({
      conversation_id: conversationId,
      sender_id: senderId,
      content,
      image_url: imageUrl ?? null,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

/**
 * Tandai semua pesan dari lawan bicara di percakapan ini sebagai sudah dibaca.
 * Dipanggil saat pengguna membuka layar chat detail.
 */
export async function markConversationAsRead(conversationId: string, currentUserId: string) {
  const { error } = await supabase
    .from('messages')
    .update({ is_read: true })
    .eq('conversation_id', conversationId)
    .neq('sender_id', currentUserId)
    .eq('is_read', false);

  if (error) throw error;
}

/**
 * Upload gambar ke Supabase Storage, mengembalikan URL publik.
 */
export async function uploadChatImage(file: File, userId: string): Promise<string> {
  const ext = file.name.split('.').pop() ?? 'jpg';
  const path = `${userId}/${Date.now()}.${ext}`;

  const { error } = await supabase.storage.from('chat-images').upload(path, file, {
    cacheControl: '3600',
    upsert: false,
  });

  if (error) throw error;

  const { data } = supabase.storage.from('chat-images').getPublicUrl(path);
  return data.publicUrl;
}

/**
 * Subscribe ke pesan baru secara realtime untuk satu percakapan.
 * Mengembalikan fungsi unsubscribe.
 */
export function subscribeToConversation(
  conversationId: string,
  onNewMessage: (message: ChatMessage) => void
) {
  const channel = supabase
    .channel(`messages:${conversationId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload) => {
        const m = payload.new as {
          id: string;
          sender_id: string;
          content: string;
          image_url: string | null;
          created_at: string;
          is_read: boolean;
        };
        onNewMessage({
          id: m.id,
          senderId: m.sender_id,
          content: m.content ?? '',
          imageUrl: m.image_url,
          timestamp: formatTime(m.created_at),
          isRead: m.is_read,
        });
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}

/**
 * Cari pengguna lain berdasarkan username (untuk mulai chat baru).
 */
export async function searchUsers(query: string, excludeUserId: string): Promise<User[]> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, display_name, avatar_url, bio')
    .ilike('username', `%${query}%`)
    .neq('id', excludeUserId)
    .limit(20);

  if (error) throw error;
  return (data ?? []).map(profileToUser);
}
