/**
 * Ekstrak pesan error yang bisa dibaca manusia dari berbagai bentuk error:
 * - Error instance JavaScript biasa
 * - PostgrestError dari Supabase (punya field .message tapi bukan instance Error)
 * - String biasa
 * - Bentuk lain yang tidak diketahui
 */
export function getErrorMessage(err: unknown): string {
  if (err instanceof Error) {
    return err.message;
  }
  if (typeof err === 'string') {
    return err;
  }
  if (err && typeof err === 'object') {
    // Supabase PostgrestError / AuthError shape: { message, details?, hint?, code? }
    const obj = err as Record<string, unknown>;
    if (typeof obj.message === 'string' && obj.message) {
      let result = obj.message;
      if (typeof obj.hint === 'string' && obj.hint) {
        result += ` (${obj.hint})`;
      }
      return result;
    }
    if (typeof obj.error_description === 'string') {
      return obj.error_description;
    }
    try {
      return JSON.stringify(obj);
    } catch {
      return 'Terjadi kesalahan yang tidak diketahui';
    }
  }
  return 'Terjadi kesalahan yang tidak diketahui';
}
