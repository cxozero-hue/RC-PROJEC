import { Home, Search, PlusCircle, BookOpen, User } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { Tab } from '@/types';

const tabs: { key: Tab; label: string; icon: typeof Home; activeIcon: typeof Home }[] = [
  { key: 'home', label: 'Beranda', icon: Home, activeIcon: Home },
  { key: 'explore', label: 'Jelajahi', icon: Search, activeIcon: Search },
  { key: 'create', label: 'Buat', icon: PlusCircle, activeIcon: PlusCircle },
  { key: 'literature', label: 'Literasi', icon: BookOpen, activeIcon: BookOpen },
  { key: 'profile', label: 'Profil', icon: User, activeIcon: User },
];

export default function BottomNav() {
  const { state, dispatch } = useApp();

  const handleTabPress = (tab: Tab) => {
    if (tab === 'create') {
      dispatch({ type: 'SET_SHOW_CREATE', show: true });
      return;
    }
    dispatch({ type: 'SET_TAB', tab });
  };

  return (
    <nav className="shrink-0 h-16 bg-white border-t border-gray-100 z-50 flex items-center justify-around select-none">
      {tabs.map((t) => {
        const isActive = state.activeTab === t.key;
        const Icon = isActive ? t.activeIcon : t.icon;
        const isCreate = t.key === 'create';

        return (
          <button
            key={t.key}
            onClick={() => handleTabPress(t.key)}
            className={`flex flex-col items-center justify-center gap-0.5 min-w-[64px] h-full relative transition-colors ${
              isCreate ? '' : ''
            }`}
          >
            {isCreate ? (
              <div className="w-12 h-12 rounded-full gold-gradient flex items-center justify-center -mt-3 shadow-lg shadow-amber-200/50">
                <PlusCircle className="w-6 h-6 text-white" />
              </div>
            ) : (
              <>
                <Icon
                  className={`w-6 h-6 transition-colors ${
                    isActive ? 'text-amber-600' : 'text-gray-400'
                  }`}
                  strokeWidth={isActive ? 2.5 : 1.5}
                />
                <span
                  className={`text-[10px] font-medium ${
                    isActive ? 'text-amber-600' : 'text-gray-400'
                  }`}
                >
                  {t.label}
                </span>
              </>
            )}
          </button>
        );
      })}
    </nav>
  );
}
