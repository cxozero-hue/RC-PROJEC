import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router'
import './index.css'
import App from './App.tsx'

/**
 * Hitung tinggi viewport sebenarnya secara dinamis dan simpan sebagai
 * CSS custom property. Ini jauh lebih reliable daripada unit CSS 'dvh'
 * di berbagai versi WebView Android, dan otomatis menyesuaikan diri
 * ke semua ukuran layar HP serta perubahan orientasi/keyboard.
 */
function setAppHeight() {
  const height = window.innerHeight;
  document.documentElement.style.setProperty('--app-height', `${height}px`);
}

setAppHeight();
window.addEventListener('resize', setAppHeight);
window.addEventListener('orientationchange', () => {
  // Delay sedikit supaya browser/WebView sudah update innerHeight setelah rotasi
  setTimeout(setAppHeight, 100);
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
)

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.error('Service worker registration failed:', err);
    });
  });
}
