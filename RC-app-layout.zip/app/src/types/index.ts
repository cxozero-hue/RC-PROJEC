export type Screen = 
  | 'login' 
  | 'register' 
  | 'videoFeed' 
  | 'explore' 
  | 'create' 
  | 'literature' 
  | 'profile' 
  | 'editProfile' 
  | 'chatList' 
  | 'chatDetail' 
  | 'articleDetail' 
  | 'poemDetail' 
  | 'storyDetail' 
  | 'live' 
  | 'about' 
  | 'notifications'
  | 'userProfile'
  | 'uploadLiterature';

export type Tab = 'home' | 'explore' | 'create' | 'literature' | 'profile';

export interface User {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatar: string;
  followers: number;
  following: number;
  likes: number;
  isFollowing?: boolean;
}

export interface VideoPost {
  id: string;
  user: User;
  caption: string;
  thumbnail: string;
  likes: number;
  comments: number;
  shares: number;
  bookmarked: boolean;
  liked: boolean;
  music?: string;
  isLive?: boolean;
  viewers?: number;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: User;
  thumbnail: string;
  category: string;
  readTime: string;
  readCount: number;
  likes: number;
  comments: number;
  publishedAt: string;
  bookmarked: boolean;
  liked: boolean;
}

export interface Poem {
  id: string;
  title: string;
  content: string;
  author: User;
  likes: number;
  comments: number;
  publishedAt: string;
  bookmarked: boolean;
  liked: boolean;
}

export interface ShortStory {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: User;
  thumbnail: string;
  genre: string;
  chapters: number;
  rating: number;
  likes: number;
  comments: number;
  publishedAt: string;
  bookmarked: boolean;
  liked: boolean;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  imageUrl?: string | null;
  timestamp: string;
  isRead: boolean;
}

export interface ChatConversation {
  id: string;
  user: User;
  messages: ChatMessage[];
  lastMessage: string;
  timestamp: string;
  unread: number;
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'system';
  user?: User;
  message: string;
  timestamp: string;
  read: boolean;
}

export type LiteratureType = 'article' | 'poem' | 'story';
