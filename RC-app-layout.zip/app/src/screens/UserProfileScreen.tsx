import { useState } from 'react';
import { ArrowLeft, Heart, FileText, UserPlus, UserCheck, MessageCircle } from 'lucide-react';
import { useApp } from '@/context/AppContext';

function formatCount(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

export default function UserProfileScreen() {
  const { state, dispatch } = useApp();
  const [isFollowing, setIsFollowing] = useState(false);
  const [profileTab, setProfileTab] = useState<'works' | 'likes'>('works');

  const allUsers = [
    ...(state.currentUser ? [state.currentUser] : []),
    ...state.videos.map(v => v.user),
    ...state.articles.map(a => a.author),
    ...state.poems.map(p => p.author),
    ...state.stories.map(s => s.author),
  ];

  const user = allUsers.find(u => u.id === state.selectedUserId);
  if (!user) return null;

  const userWorks = [
    ...state.videos.filter(v => v.user.id === user.id),
    ...state.articles.filter(a => a.author.id === user.id),
    ...state.poems.filter(p => p.author.id === user.id),
    ...state.stories.filter(s => s.author.id === user.id),
  ];

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center px-4 h-14 border-b">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="font-semibold text-base">Profil</span>
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {/* Profile Header */}
        <div className="relative">
          <div className="h-32 dark-gradient" />
          <div className="px-4 -mt-12 flex flex-col items-center">
            <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center border-4 border-white shadow-md">
              <span className="text-2xl font-bold text-gray-400">{user.displayName[0]}</span>
            </div>
            <h2 className="font-heading text-base font-bold mt-2">{user.displayName}</h2>
            <p className="text-gray-400 text-sm">@{user.username}</p>
            <p className="text-gray-600 text-sm mt-1 text-center">{user.bio || 'Belum ada bio'}</p>

            {/* Stats */}
            <div className="flex items-center gap-6 mt-3">
              <div className="text-center">
                <p className="font-bold text-sm">{formatCount(user.following)}</p>
                <p className="text-gray-400 text-xs">Mengikuti</p>
              </div>
              <div className="text-center">
                <p className="font-bold text-sm">{formatCount(user.followers)}</p>
                <p className="text-gray-400 text-xs">Pengikut</p>
              </div>
              <div className="text-center">
                <p className="font-bold text-sm">{formatCount(user.likes)}</p>
                <p className="text-gray-400 text-xs">Suka</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mt-4 w-full">
              <button
                onClick={() => setIsFollowing(!isFollowing)}
                className={`flex-1 h-9 rounded-lg text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  isFollowing
                    ? 'border border-gray-200 text-gray-700'
                    : 'gold-gradient text-white'
                }`}
              >
                {isFollowing ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                {isFollowing ? 'Mengikuti' : 'Ikuti'}
              </button>
              <button
                onClick={() => {
                  dispatch({ type: 'SHOW_TOAST', message: 'Fitur pesan segera hadir!' });
                  setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
                }}
                className="flex-1 h-9 border border-gray-200 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-4 h-4" />
                Pesan
              </button>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="flex border-b mt-5 mx-4">
          {[
            { key: 'works' as const, label: 'Karya', icon: FileText },
            { key: 'likes' as const, label: 'Suka', icon: Heart },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setProfileTab(tab.key)}
              className={`flex-1 flex items-center justify-center gap-1.5 pb-2.5 text-sm font-medium border-b-2 transition-colors ${
                profileTab === tab.key ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-400'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="px-4 py-4">
          {profileTab === 'works' && (
            userWorks.length > 0 ? (
              <div className="grid grid-cols-3 gap-1">
                {userWorks.map((w: any, i) => (
                  <div key={i} className="aspect-[3/4] bg-gray-200 rounded-lg overflow-hidden relative">
                    {'thumbnail' in w && w.thumbnail ? (
                      <img src={w.thumbnail} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <FileText className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Belum ada karya</p>
              </div>
            )
          )}
          {profileTab === 'likes' && (
            <div className="text-center py-12">
              <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">Daftar suka privat</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
