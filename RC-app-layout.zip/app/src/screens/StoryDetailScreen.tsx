import { ArrowLeft, Heart, MessageCircle, Share2, Bookmark, BookOpen } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function StoryDetailScreen() {
  const { state, dispatch } = useApp();
  const story = state.stories.find(s => s.id === state.selectedStoryId);

  if (!story) return null;

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b bg-white z-10">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <span className="font-semibold text-sm">Cerpen</span>
        <div className="flex items-center gap-2">
          <button onClick={() => dispatch({ type: 'TOGGLE_BOOKMARK_STORY', storyId: story.id })}>
            <Bookmark className={`w-5 h-5 ${story.bookmarked ? 'text-amber-500 fill-amber-500' : 'text-gray-600'}`} />
          </button>
          <button><Share2 className="w-5 h-5 text-gray-600" /></button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {/* Thumbnail */}
        <img src={story.thumbnail} alt={story.title} className="w-full aspect-video object-cover" />

        <div className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-purple-50 text-purple-700 text-[11px] font-medium px-2.5 py-0.5 rounded-full">
              {story.genre}
            </span>
            <span className="text-amber-600 text-xs font-medium">⭐ {story.rating}</span>
            <span className="text-gray-400 text-xs flex items-center gap-1">
              <BookOpen className="w-3 h-3" />
              {story.chapters} bab
            </span>
          </div>

          <h1 className="font-heading text-xl font-bold">{story.title}</h1>

          <div className="flex items-center gap-3 mt-3">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
              <span className="text-xs font-bold">{story.author.displayName[0]}</span>
            </div>
            <div>
              <p className="text-sm font-medium">{story.author.displayName}</p>
              <p className="text-gray-400 text-xs">@{story.author.username}</p>
            </div>
            <button
              onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: story.author.id })}
              className="ml-auto gold-gradient text-white text-xs font-semibold px-3 py-1.5 rounded-full"
            >
              Ikuti
            </button>
          </div>

          <div className="border-t my-4" />

          <div className="prose prose-sm max-w-none">
            <p className="text-gray-600 italic mb-4">{story.excerpt}</p>
            <p className="text-base leading-relaxed text-gray-700 whitespace-pre-line">{story.content}</p>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="shrink-0 border-t bg-white px-4 py-2 flex items-center justify-between">
        <button
          onClick={() => dispatch({ type: 'TOGGLE_LIKE_STORY', storyId: story.id })}
          className={`flex items-center gap-1.5 ${story.liked ? 'text-red-500' : 'text-gray-600'}`}
        >
          <Heart className={`w-5 h-5 ${story.liked ? 'fill-red-500' : ''}`} />
          <span className="text-sm">{story.likes}</span>
        </button>
        <button className="flex items-center gap-1.5 text-gray-600">
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm">{story.comments}</span>
        </button>
        <button><Share2 className="w-5 h-5 text-gray-600" /></button>
      </div>
    </div>
  );
}
