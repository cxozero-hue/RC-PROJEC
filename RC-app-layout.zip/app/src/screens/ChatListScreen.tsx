import { useState } from 'react';
import { ArrowLeft, Edit3, Bell, MessageCircle, Search, X, Loader2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { searchUsers, getOrCreateConversation, fetchConversations } from '@/lib/chatService';
import { getErrorMessage } from '@/lib/errorUtils';
import type { User } from '@/types';

export default function ChatListScreen() {
  const { state, dispatch } = useApp();
  const [activeMsgTab, setActiveMsgTab] = useState<'messages' | 'notifications'>('messages');
  const [showNewChat, setShowNewChat] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [searching, setSearching] = useState(false);
  const [startingChatWith, setStartingChatWith] = useState<string | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const unreadCount = state.conversations.reduce((sum, c) => sum + c.unread, 0);
  const unreadNotifs = state.notifications.filter(n => !n.read).length;
  const currentUserId = state.currentUser?.id;

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    setSearchError(null);
    if (!currentUserId || query.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    try {
      const results = await searchUsers(query.trim(), currentUserId);
      setSearchResults(results);
    } catch (err) {
      const message = getErrorMessage(err);
      console.error('Search error:', err);
      setSearchError(message);
      setSearchResults([]);
    } finally {
      setSearching(false);
    }
  };

  const handleStartChat = async (otherUser: User) => {
    if (!currentUserId || startingChatWith) return;
    setStartingChatWith(otherUser.id);
    try {
      await getOrCreateConversation(currentUserId, otherUser.id);
      const conversations = await fetchConversations(currentUserId);
      dispatch({ type: 'SET_CONVERSATIONS', conversations });
      const newConv = conversations.find(c => c.user.id === otherUser.id);
      setShowNewChat(false);
      setSearchQuery('');
      setSearchResults([]);
      if (newConv) {
        dispatch({ type: 'SET_SELECTED_CHAT', chatId: newConv.id });
      }
    } catch (err) {
      const detail = getErrorMessage(err);
      console.error('Gagal memulai chat:', err);
      dispatch({ type: 'SHOW_TOAST', message: `Gagal memulai percakapan: ${detail}`, duration: 6000 });
    } finally {
      setStartingChatWith(null);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="font-heading text-lg font-bold">Pesan</span>
        </h1>
        <button onClick={() => setShowNewChat(true)} className="w-10 h-10 flex items-center justify-center relative">
          <Edit3 className="w-5 h-5" />
        </button>
      </div>

      {/* Tabs */}
      <div className="shrink-0 flex border-b mx-4">
        <button
          onClick={() => setActiveMsgTab('messages')}
          className={`flex-1 flex items-center justify-center gap-1.5 pb-2.5 text-sm font-medium border-b-2 transition-colors ${
            activeMsgTab === 'messages' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-400'
          }`}
        >
          <MessageCircle className="w-4 h-4" />
          Pesan
          {unreadCount > 0 && (
            <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unreadCount}</span>
          )}
        </button>
        <button
          onClick={() => setActiveMsgTab('notifications')}
          className={`flex-1 flex items-center justify-center gap-1.5 pb-2.5 text-sm font-medium border-b-2 transition-colors ${
            activeMsgTab === 'notifications' ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-400'
          }`}
        >
          <Bell className="w-4 h-4" />
          Notifikasi
          {unreadNotifs > 0 && (
            <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unreadNotifs}</span>
          )}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {activeMsgTab === 'messages' ? (
          <div>
            {state.conversations.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
                <MessageCircle className="w-12 h-12 text-gray-300 mb-3" />
                <p className="text-gray-500 text-sm">Belum ada percakapan.</p>
                <button
                  onClick={() => setShowNewChat(true)}
                  className="mt-3 text-amber-600 text-sm font-medium"
                >
                  Mulai chat baru
                </button>
              </div>
            )}
            {state.conversations.map(conv => (
              <button
                key={conv.id}
                onClick={() => dispatch({ type: 'SET_SELECTED_CHAT', chatId: conv.id })}
                className="w-full flex items-start gap-3 px-4 py-3 text-left border-b border-gray-50 active:bg-gray-50 transition-colors"
              >
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center shrink-0 overflow-hidden">
                    {conv.user.avatar ? (
                      <img src={conv.user.avatar} alt={conv.user.displayName} className="w-full h-full object-cover" />
                    ) : (
                      <span className="font-bold text-gray-600">{conv.user.displayName[0]}</span>
                    )}
                  </div>
                  {conv.unread > 0 && (
                    <div className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-[10px] font-bold">{conv.unread}</span>
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className={`text-sm ${conv.unread > 0 ? 'font-bold' : 'font-medium'}`}>{conv.user.displayName}</p>
                    <span className="text-gray-400 text-xs">{conv.timestamp}</span>
                  </div>
                  <p className={`text-sm truncate mt-0.5 ${conv.unread > 0 ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>
                    {conv.lastMessage}
                  </p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div>
            {state.notifications.map(notif => (
              <button
                key={notif.id}
                onClick={() => dispatch({ type: 'READ_NOTIFICATION', notifId: notif.id })}
                className={`w-full flex items-start gap-3 px-4 py-3 text-left border-b border-gray-50 active:bg-gray-50 transition-colors ${
                  !notif.read ? 'bg-amber-50/30' : ''
                }`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  notif.type === 'like' ? 'bg-red-100' :
                  notif.type === 'comment' ? 'bg-blue-100' :
                  notif.type === 'follow' ? 'bg-green-100' :
                  notif.type === 'mention' ? 'bg-purple-100' :
                  'bg-gray-100'
                }`}>
                  {notif.type === 'like' && <span className="text-red-500 text-lg">❤️</span>}
                  {notif.type === 'comment' && <span className="text-blue-500 text-lg">💬</span>}
                  {notif.type === 'follow' && <span className="text-green-500 text-lg">👤</span>}
                  {notif.type === 'mention' && <span className="text-purple-500 text-lg">@</span>}
                  {notif.type === 'system' && <span className="text-gray-500 text-lg">🔔</span>}
                </div>
                <div className="flex-1">
                  <p className={`text-sm ${!notif.read ? 'font-medium' : ''}`}>
                    {notif.user ? <span className="font-semibold">@{notif.user.username}</span> : ''} {notif.message}
                  </p>
                  <p className="text-gray-400 text-xs mt-0.5">{notif.timestamp}</p>
                </div>
                {!notif.read && <div className="w-2 h-2 bg-amber-500 rounded-full mt-2 shrink-0" />}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* New Chat Modal */}
      {showNewChat && (
        <div className="absolute inset-0 bg-white z-20 flex flex-col">
          <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b">
            <button
              onClick={() => { setShowNewChat(false); setSearchQuery(''); setSearchResults([]); setSearchError(null); }}
              className="w-10 h-10 flex items-center justify-center -ml-2"
            >
              <X className="w-6 h-6" />
            </button>
            <h2 className="font-heading text-lg font-bold">Chat Baru</h2>
            <div className="w-10" />
          </div>
          <div className="p-4 shrink-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => handleSearch(e.target.value)}
                placeholder="Cari ID pengguna..."
                autoFocus
                className="w-full h-11 bg-gray-100 rounded-full pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto no-scrollbar">
            {searching && (
              <div className="flex justify-center py-6">
                <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
              </div>
            )}
            {!searching && searchError && (
              <div className="px-4 py-6 text-center">
                <p className="text-red-500 text-sm font-medium">Gagal mencari pengguna</p>
                <p className="text-gray-400 text-xs mt-1">{searchError}</p>
              </div>
            )}
            {!searching && !searchError && searchQuery.trim().length >= 2 && searchResults.length === 0 && (
              <p className="text-center text-gray-400 text-sm py-6">Pengguna tidak ditemukan.</p>
            )}
            {searchResults.map(user => (
              <button
                key={user.id}
                onClick={() => handleStartChat(user)}
                disabled={startingChatWith === user.id}
                className="w-full flex items-center gap-3 px-4 py-3 text-left active:bg-gray-50 transition-colors"
              >
                <div className="w-11 h-11 rounded-full bg-gray-200 flex items-center justify-center shrink-0 overflow-hidden">
                  {user.avatar ? (
                    <img src={user.avatar} alt={user.displayName} className="w-full h-full object-cover" />
                  ) : (
                    <span className="font-bold text-gray-600">{user.displayName[0]}</span>
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{user.displayName}</p>
                  <p className="text-gray-400 text-xs">@{user.username}</p>
                </div>
                {startingChatWith === user.id && <Loader2 className="w-4 h-4 animate-spin text-gray-400" />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
