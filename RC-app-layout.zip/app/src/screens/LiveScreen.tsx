import { useState } from 'react';
import { X, Eye, Heart, Share2, Mic, Send } from 'lucide-react';
import { useApp } from '@/context/AppContext';

const demoMessages = [
  { id: 1, user: 'Ahmad', text: 'Halo! Semangat menulisnya!', color: 'bg-blue-500' },
  { id: 2, user: 'Bella', text: 'Pengen ikut live menulis juga nih', color: 'bg-pink-500' },
  { id: 3, user: 'Citra', text: 'Tulis cerpen horor dong!', color: 'bg-green-500' },
  { id: 4, user: 'Dedi', text: 'Suara penyiarnya jelas banget', color: 'bg-purple-500' },
  { id: 5, user: 'Eka', text: 'Siap gabung suara', color: 'bg-orange-500' },
  { id: 6, user: 'Fira', text: 'Tema hari ini apa?', color: 'bg-teal-500' },
  { id: 7, user: 'Gita', text: 'Semoga lancar!', color: 'bg-red-500' },
];

export default function LiveScreen() {
  const { dispatch } = useApp();
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState(demoMessages);
  const [joinedAudio, setJoinedAudio] = useState(false);

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    setMessages(prev => [...prev, { id: Date.now(), user: 'Saya', text: chatInput, color: 'bg-amber-500' }]);
    setChatInput('');
  };

  return (
    <div className="h-full relative bg-black">
      {/* Background Image */}
      <img
        src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=1200&fit=crop"
        alt=""
        className="w-full h-full object-cover opacity-60"
      />

      {/* Live Header */}
      <div className="absolute top-0 left-0 right-0 pt-11 px-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center border border-white/30">
            <span className="text-white text-sm font-bold">K</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-semibold text-sm">@komunitas_menulis</span>
              <div className="flex items-center gap-1 bg-red-600 px-1.5 py-0.5 rounded">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse-live" />
                <span className="text-white text-[10px] font-bold">LIVE</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-white/70 text-xs">
              <Eye className="w-3 h-3" />
              <span>1.2K penonton</span>
            </div>
          </div>
        </div>
        <button
          onClick={() => dispatch({ type: 'GO_BACK' })}
          className="w-9 h-9 bg-black/30 rounded-full flex items-center justify-center"
        >
          <X className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Live Chat (Right side) */}
      <div className="absolute right-3 top-32 bottom-32 w-48 flex flex-col justify-end z-10 overflow-hidden">
        <div className="space-y-2">
          {messages.slice(-6).map(msg => (
            <div key={msg.id} className="flex items-start gap-2">
              <div className={`w-5 h-5 rounded-full ${msg.color} flex items-center justify-center shrink-0`}>
                <span className="text-white text-[8px] font-bold">{msg.user[0]}</span>
              </div>
              <div>
                <span className="text-white/80 text-[11px] font-semibold">{msg.user}</span>
                <p className="text-white/90 text-[11px] text-shadow">{msg.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Joined Audio Indicator */}
      {joinedAudio && (
        <div className="absolute top-24 left-4 bg-amber-500/90 backdrop-blur-sm rounded-xl px-3 py-2 z-10">
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-white" />
            <span className="text-white text-xs font-medium">Anda bergabung suara</span>
          </div>
        </div>
      )}

      {/* Bottom Actions */}
      <div className="absolute bottom-0 left-0 right-0 px-4 pb-6 z-10">
        {/* Chat Input */}
        <div className="flex items-center gap-2 mb-3">
          <input
            type="text"
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
            placeholder="Kirim pesan..."
            className="flex-1 h-10 bg-white/20 backdrop-blur-sm rounded-full px-4 text-white text-sm placeholder-white/50 focus:outline-none"
          />
          <button
            onClick={handleSendMessage}
            className="w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-1 text-white">
              <Heart className="w-6 h-6" />
              <span className="text-xs">45K</span>
            </button>
            <button className="text-white">
              <Share2 className="w-6 h-6" />
            </button>
          </div>
          <button
            onClick={() => setJoinedAudio(!joinedAudio)}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
              joinedAudio
                ? 'bg-red-500 text-white'
                : 'gold-gradient text-white'
            }`}
          >
            {joinedAudio ? 'Akhiri Suara' : 'Gabung Suara'}
          </button>
          <button
            onClick={() => dispatch({ type: 'GO_BACK' })}
            className="bg-red-600 text-white text-sm font-semibold px-4 py-2 rounded-full"
          >
            Akhiri
          </button>
        </div>
      </div>
    </div>
  );
}
