import { useState } from 'react';
import { Search, Bookmark, Heart, Clock, Eye, ChevronRight } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { LiteratureType } from '@/types';

const subTabs: { key: LiteratureType; label: string }[] = [
  { key: 'article', label: 'Artikel' },
  { key: 'poem', label: 'Puisi' },
  { key: 'story', label: 'Cerpen' },
];

const categoryChips = ['Terbaru', 'Terpopuler', 'Untukmu', 'Pendidikan', 'Budaya', 'Cinta', 'Inspirasi', 'Horor', 'Komedi'];

export default function LiteratureScreen() {
  const { state, dispatch } = useApp();
  const [activeChip, setActiveChip] = useState('Terbaru');

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Top Bar */}
      <div className="shrink-0 px-4 pt-3 pb-2 flex items-center justify-between">
        <h1 className="font-heading text-xl font-bold">Literasi</h1>
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 flex items-center justify-center">
            <Search className="w-5 h-5 text-gray-700" />
          </button>
          <button className="w-10 h-10 flex items-center justify-center">
            <Bookmark className="w-5 h-5 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="shrink-0 px-4 pb-2 flex gap-2">
        {subTabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => dispatch({ type: 'SET_LITERATURE_TYPE', litType: tab.key })}
            className={`h-9 px-4 rounded-full text-sm font-medium transition-all ${
              state.selectedLiteratureType === tab.key
                ? 'bg-amber-50 text-amber-700 border border-amber-400'
                : 'bg-gray-100 text-gray-500'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Category Chips */}
      <div className="shrink-0 px-4 py-2 flex gap-2 overflow-x-auto no-scrollbar">
        {categoryChips.map((chip) => (
          <button
            key={chip}
            onClick={() => setActiveChip(chip)}
            className={`shrink-0 h-8 px-3 rounded-full text-xs font-medium transition-all ${
              activeChip === chip
                ? 'bg-amber-50 text-amber-700 border border-amber-400'
                : 'bg-gray-100 text-gray-500'
            }`}
          >
            {chip}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 pb-4">
        {state.selectedLiteratureType === 'article' && (
          <div className="space-y-4">
            {state.articles.map((article) => (
              <button
                key={article.id}
                className="w-full text-left border-b border-gray-100 pb-4 last:border-0"
                onClick={() => dispatch({ type: 'SET_SELECTED_ARTICLE', articleId: article.id })}
              >
                <img
                  src={article.thumbnail}
                  alt={article.title}
                  className="w-full aspect-video rounded-xl object-cover mb-3"
                />
                <span className="inline-block bg-amber-50 text-amber-700 text-[11px] font-medium px-2.5 py-0.5 rounded-full mb-2">
                  {article.category}
                </span>
                <h3 className="font-semibold text-base leading-snug">{article.title}</h3>
                <p className="text-gray-500 text-sm mt-1 line-clamp-2">{article.excerpt}</p>
                <div className="flex items-center gap-2 mt-2 text-gray-400 text-xs">
                  <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center">
                    <span className="font-bold text-[9px]">{article.author.displayName[0]}</span>
                  </div>
                  <span>{article.author.displayName}</span>
                  <span>•</span>
                  <Clock className="w-3 h-3" />
                  <span>{article.readTime}</span>
                  <span>•</span>
                  <Eye className="w-3 h-3" />
                  <span>{article.readCount >= 1000 ? (article.readCount / 1000).toFixed(1) + 'K' : article.readCount}</span>
                </div>
              </button>
            ))}
          </div>
        )}

        {state.selectedLiteratureType === 'poem' && (
          <div className="space-y-4">
            {state.poems.map((poem) => (
              <button
                key={poem.id}
                className="w-full bg-gray-50 rounded-2xl p-5 text-left relative overflow-hidden"
                onClick={() => dispatch({ type: 'SET_SELECTED_POEM', poemId: poem.id })}
              >
                <div className="text-gray-200 text-6xl font-display absolute top-2 left-3 leading-none select-none">&ldquo;</div>
                <h3 className="font-display text-lg font-bold italic text-center relative z-10">{poem.title}</h3>
                <div className="text-center mt-3 relative z-10">
                  {poem.content.split('\n').slice(0, 6).map((line, i) => (
                    <p key={i} className="font-display text-sm text-gray-600 leading-loose">
                      {line || '\u00A0'}
                    </p>
                  ))}
                  {poem.content.split('\n').length > 6 && (
                    <p className="text-amber-600 text-xs mt-2 font-medium">Baca selengkapnya...</p>
                  )}
                </div>
                <p className="text-amber-600 text-xs font-medium text-center mt-3 relative z-10">— {poem.author.displayName}</p>
                <div className="flex items-center justify-center gap-4 mt-3 text-gray-400 text-xs relative z-10">
                  <span className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5" />
                    {poem.likes >= 1000 ? (poem.likes / 1000).toFixed(1) + 'K' : poem.likes}
                  </span>
                  <span>{poem.publishedAt}</span>
                </div>
              </button>
            ))}
          </div>
        )}

        {state.selectedLiteratureType === 'story' && (
          <div className="space-y-4">
            {state.stories.map((story) => (
              <button
                key={story.id}
                className="w-full text-left border-b border-gray-100 pb-4 last:border-0"
                onClick={() => dispatch({ type: 'SET_SELECTED_STORY', storyId: story.id })}
              >
                <img
                  src={story.thumbnail}
                  alt={story.title}
                  className="w-full aspect-video rounded-xl object-cover mb-3"
                />
                <div className="flex items-center gap-2 mb-1">
                  <span className="bg-purple-50 text-purple-700 text-[11px] font-medium px-2 py-0.5 rounded-full">
                    {story.genre}
                  </span>
                  <span className="text-amber-600 text-[11px] font-medium">⭐ {story.rating}</span>
                </div>
                <h3 className="font-semibold text-base">{story.title}</h3>
                <p className="text-gray-500 text-sm mt-1 line-clamp-2">{story.excerpt}</p>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-2 text-gray-400 text-xs">
                    <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center">
                      <span className="font-bold text-[9px]">{story.author.displayName[0]}</span>
                    </div>
                    <span>{story.author.displayName}</span>
                    <span>•</span>
                    <span>{story.chapters} bab</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
