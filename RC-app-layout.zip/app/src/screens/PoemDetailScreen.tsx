import { ArrowLeft, Heart, MessageCircle, Share2, Bookmark } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function PoemDetailScreen() {
  const { state, dispatch } = useApp();
  const poem = state.poems.find(p => p.id === state.selectedPoemId);

  if (!poem) return null;

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b bg-white z-10">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <span className="font-semibold text-sm">Puisi</span>
        <div className="flex items-center gap-2">
          <button onClick={() => dispatch({ type: 'TOGGLE_BOOKMARK_POEM', poemId: poem.id })}>
            <Bookmark className={`w-5 h-5 ${poem.bookmarked ? 'text-amber-500 fill-amber-500' : 'text-gray-600'}`} />
          </button>
          <button><Share2 className="w-5 h-5 text-gray-600" /></button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        <div className="p-6 pb-4">
          <h1 className="font-display text-2xl font-bold italic text-center">{poem.title}</h1>

          <div className="text-center mt-6">
            {poem.content.split('\n').map((line, i) => (
              <p key={i} className="font-display text-base italic text-gray-700 leading-[2.2]">
                {line || '\u00A0'}
              </p>
            ))}
          </div>

          <p className="text-amber-600 text-sm font-medium text-center mt-6">
            — {poem.author.displayName}
          </p>

          <p className="text-gray-400 text-xs text-center mt-2">{poem.publishedAt}</p>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="shrink-0 border-t bg-white px-4 py-2 flex items-center justify-between">
        <button
          onClick={() => dispatch({ type: 'TOGGLE_LIKE_POEM', poemId: poem.id })}
          className={`flex items-center gap-1.5 ${poem.liked ? 'text-red-500' : 'text-gray-600'}`}
        >
          <Heart className={`w-5 h-5 ${poem.liked ? 'fill-red-500' : ''}`} />
          <span className="text-sm">{poem.likes}</span>
        </button>
        <button className="flex items-center gap-1.5 text-gray-600">
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm">{poem.comments}</span>
        </button>
        <button><Share2 className="w-5 h-5 text-gray-600" /></button>
      </div>
    </div>
  );
}
