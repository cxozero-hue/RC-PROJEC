import { Video, BookText, Feather, FileText, Radio, Image, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { useState } from 'react';
import type { Article, Poem, ShortStory } from '@/types';

const createOptions = [
  { key: 'video', label: 'Video Pendek', desc: 'Rekam atau upload video', icon: Video, color: 'text-blue-500 bg-blue-50' },
  { key: 'story', label: 'Cerpen', desc: 'Tulis cerita pendek', icon: BookText, color: 'text-purple-500 bg-purple-50' },
  { key: 'poem', label: 'Puisi', desc: 'Tulis puisi atau syair', icon: Feather, color: 'text-amber-500 bg-amber-50' },
  { key: 'article', label: 'Artikel', desc: 'Tulis artikel atau opini', icon: FileText, color: 'text-green-500 bg-green-50' },
  { key: 'live', label: 'Mulai Live', desc: 'Siaran langsung', icon: Radio, color: 'text-red-500 bg-red-50' },
  { key: 'gallery', label: 'Galeri', desc: 'Upload dari galeri', icon: Image, color: 'text-orange-500 bg-orange-50' },
];

export default function CreateScreen() {
  const { dispatch } = useApp();
  const [createMode, setCreateMode] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [genre, setGenre] = useState('');

  const handlePublish = () => {
    if (!title.trim() || !content.trim()) return;

    if (createMode === 'article') {
      const article: Article = {
        id: `a-${Date.now()}`,
        title,
        excerpt: content.slice(0, 120) + '...',
        content,
        author: { id: 'current-user', username: 'saya', displayName: 'Saya', bio: '', avatar: '', followers: 0, following: 0, likes: 0 },
        thumbnail: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=340&fit=crop',
        category: genre || 'Umum',
        readTime: `${Math.max(1, Math.ceil(content.length / 500))} menit`,
        readCount: 0,
        likes: 0,
        comments: 0,
        publishedAt: 'Baru saja',
        bookmarked: false,
        liked: false,
      };
      dispatch({ type: 'ADD_LITERATURE', item: article });
    } else if (createMode === 'poem') {
      const poem: Poem = {
        id: `p-${Date.now()}`,
        title,
        content,
        author: { id: 'current-user', username: 'saya', displayName: 'Saya', bio: '', avatar: '', followers: 0, following: 0, likes: 0 },
        likes: 0,
        comments: 0,
        publishedAt: 'Baru saja',
        bookmarked: false,
        liked: false,
      };
      dispatch({ type: 'ADD_LITERATURE', item: poem });
    } else if (createMode === 'story') {
      const story: ShortStory = {
        id: `s-${Date.now()}`,
        title,
        excerpt: content.slice(0, 120) + '...',
        content,
        author: { id: 'current-user', username: 'saya', displayName: 'Saya', bio: '', avatar: '', followers: 0, following: 0, likes: 0 },
        thumbnail: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=600&h=340&fit=crop',
        genre: genre || 'Umum',
        chapters: 1,
        rating: 0,
        likes: 0,
        comments: 0,
        publishedAt: 'Baru saja',
        bookmarked: false,
        liked: false,
      };
      dispatch({ type: 'ADD_LITERATURE', item: story });
    }

    dispatch({ type: 'SHOW_TOAST', message: 'Karya berhasil dipublikasikan!' });
    setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
    dispatch({ type: 'SET_SHOW_CREATE', show: false });
    dispatch({ type: 'SET_TAB', tab: 'literature' });
    setCreateMode(null);
    setTitle('');
    setContent('');
    setGenre('');
  };

  if (createMode) {
    return (
      <div className="h-full flex flex-col bg-white">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b">
          <button onClick={() => setCreateMode(null)} className="text-gray-500">
            <X className="w-6 h-6" />
          </button>
          <h2 className="font-semibold">
            {createMode === 'story' ? 'Tulis Cerpen' : createMode === 'poem' ? 'Tulis Puisi' : 'Tulis Artikel'}
          </h2>
          <button
            onClick={handlePublish}
            className={`text-sm font-semibold ${title.trim() && content.trim() ? 'text-amber-600' : 'text-gray-400'}`}
            disabled={!title.trim() || !content.trim()}
          >
            Publikasikan
          </button>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-4">
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="Judul karya Anda..."
            className="w-full text-xl font-bold placeholder-gray-300 focus:outline-none"
          />
          {createMode !== 'poem' && (
            <input
              type="text"
              value={genre}
              onChange={e => setGenre(e.target.value)}
              placeholder="Kategori/Genre (opsional)"
              className="w-full text-sm placeholder-gray-300 focus:outline-none border-b pb-2"
            />
          )}
          <textarea
            value={content}
            onChange={e => setContent(e.target.value)}
            placeholder="Tulis di sini..."
            className={`w-full flex-1 min-h-[300px] resize-none focus:outline-none text-base leading-relaxed ${
              createMode === 'poem' ? 'font-display text-center italic' : ''
            }`}
            style={{ lineHeight: createMode === 'poem' ? 2.0 : 1.8 }}
          />
          <div className="text-right text-gray-400 text-xs">
            {content.length} karakter
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <h2 className="font-heading text-xl font-bold mb-1">Buat Konten</h2>
        <p className="text-gray-400 text-sm mb-8">Pilih jenis konten yang ingin dibagikan</p>

        <div className="grid grid-cols-2 gap-4 w-full max-w-sm">
          {createOptions.map((opt) => (
            <button
              key={opt.key}
              onClick={() => {
                if (opt.key === 'live') {
                  dispatch({ type: 'SET_SHOW_CREATE', show: false });
                  dispatch({ type: 'NAVIGATE', screen: 'live' });
                } else if (['article', 'poem', 'story'].includes(opt.key)) {
                  setCreateMode(opt.key);
                } else if (opt.key === 'video' || opt.key === 'gallery') {
                  dispatch({ type: 'SHOW_TOAST', message: 'Fitur ini akan segera hadir!' });
                  setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
                }
              }}
              className="flex flex-col items-center gap-2 bg-gray-50 rounded-2xl p-5 active:bg-gray-100 transition-colors"
            >
              <div className={`w-12 h-12 rounded-xl ${opt.color} flex items-center justify-center`}>
                <opt.icon className="w-6 h-6" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-sm">{opt.label}</p>
                <p className="text-gray-400 text-[11px] mt-0.5">{opt.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
