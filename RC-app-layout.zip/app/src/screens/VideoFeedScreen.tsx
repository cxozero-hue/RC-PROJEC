import { useState, useRef, useCallback, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, MoreVertical, Search, Music, UserPlus } from 'lucide-react';
import { useApp } from '@/context/AppContext';

function formatCount(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

export default function VideoFeedScreen() {
  const { state, dispatch } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showCommentsSheet, setShowCommentsSheet] = useState(false);
  const [showShareSheet, setShowShareSheet] = useState(false);
  const [heartAnim, setHeartAnim] = useState<{ x: number; y: number; id: number } | null>(null);
  const feedRef = useRef<HTMLDivElement>(null);

  const videos = state.videos;
  const currentVideo = videos[currentIndex];
  const unreadCount = state.conversations.reduce((sum, c) => sum + c.unread, 0);

  // Track video index berdasarkan IntersectionObserver
  useEffect(() => {
    const container = feedRef.current;
    if (!container) return;
    const items = container.querySelectorAll('.video-feed-item');
    if (!items.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            const idx = Number((entry.target as HTMLElement).dataset.index);
            setCurrentIndex(idx);
          }
        });
      },
      { threshold: 0.5, root: container }
    );

    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, [videos.length]);

  const handleDoubleTap = useCallback((e: React.MouseEvent, videoId: string, liked: boolean) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    setHeartAnim({ x: e.clientX - rect.left, y: e.clientY - rect.top, id: Date.now() });
    if (!liked) dispatch({ type: 'TOGGLE_LIKE_VIDEO', videoId });
    setTimeout(() => setHeartAnim(null), 800);
  }, [dispatch]);

  const scrollToIndex = useCallback((idx: number) => {
    feedRef.current?.querySelectorAll('.video-feed-item')[idx]?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  return (
    <div className="h-full relative bg-black overflow-hidden">

      {/* ── FIXED TOP HEADER ── */}
      {/* Header tinggi: safe-area-top + 96px = cukup untuk logo + pill + padding */}
      <div
        className="absolute top-0 left-0 right-0 z-30"
        style={{
          background: 'linear-gradient(to bottom, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.3) 70%, transparent 100%)',
          paddingTop: 'max(40px, env(safe-area-inset-top, 40px))',
          paddingBottom: '8px',
          paddingLeft: '16px',
          paddingRight: '16px',
        }}
      >
        {/* Baris 1: Logo + Tab Pill + Ikon kanan */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 flex-1">
            <img src="/logo.jpg" alt="Ruang Cerita" className="w-7 h-7 rounded-lg object-cover shrink-0" />
            <div className="flex bg-white/20 backdrop-blur-sm rounded-full p-0.5">
              <button
                className="px-3 py-1 rounded-full text-white/80 text-xs font-medium active:bg-white/20"
                onClick={() => {}}
              >
                Mengikuti
              </button>
              <button
                className="px-3 py-1 rounded-full bg-white text-black text-xs font-bold shadow"
                onClick={() => {}}
              >
                Untuk Anda
              </button>
              <button
                className="px-3 py-1 rounded-full text-white/80 text-xs font-medium active:bg-white/20"
                onClick={() => dispatch({ type: 'NAVIGATE', screen: 'live' })}
              >
                Live
              </button>
            </div>
          </div>
          <div className="flex items-center gap-0.5 ml-2 shrink-0">
            <button className="w-9 h-9 flex items-center justify-center active:opacity-60">
              <Search className="w-5 h-5 text-white drop-shadow" />
            </button>
            <button
              onClick={() => dispatch({ type: 'NAVIGATE', screen: 'chatList' })}
              className="w-9 h-9 flex items-center justify-center relative active:opacity-60"
            >
              <MessageCircle className="w-5 h-5 text-white drop-shadow" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              )}
            </button>
          </div>
        </div>

        {/* Baris 2: Story Rings — langsung di bawah header, tidak tumpang tindih */}
        <div className="flex gap-3 overflow-x-auto no-scrollbar mt-2 pb-1">
          <button className="flex flex-col items-center gap-1 shrink-0">
            <div className="w-11 h-11 rounded-full border-2 border-dashed border-amber-400 flex items-center justify-center bg-white/10 backdrop-blur-sm">
              <UserPlus className="w-4 h-4 text-amber-400" />
            </div>
            <span className="text-white text-[9px]">Tambah</span>
          </button>
          {videos.slice(0, 6).map((v, i) => (
            <button
              key={v.id}
              className="flex flex-col items-center gap-1 shrink-0 active:opacity-70"
              onClick={() => scrollToIndex(i)}
            >
              <div className={`w-11 h-11 rounded-full p-[2px] ${i === currentIndex ? 'bg-gradient-to-tr from-amber-400 to-amber-600' : 'bg-gray-600'}`}>
                <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center overflow-hidden">
                  <span className="text-white text-xs font-bold">{v.user.displayName[0]}</span>
                </div>
              </div>
              <span className="text-white text-[9px] max-w-[44px] truncate">{v.user.displayName}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ── SNAP-SCROLL VIDEO FEED ── */}
      <div ref={feedRef} className="video-feed-container">
        {videos.map((video, index) => (
          <div
            key={video.id}
            data-index={index}
            className="video-feed-item"
            onDoubleClick={(e) => handleDoubleTap(e, video.id, video.liked)}
          >
            {/* Thumbnail */}
            <img
              src={video.thumbnail}
              alt=""
              className="w-full h-full object-cover"
              loading={index <= 1 ? 'eager' : 'lazy'}
            />

            {/* Gradient overlay bottom */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/75 pointer-events-none" />

            {/* Right Actions */}
            <div
              className="absolute right-3 flex flex-col items-center gap-5 z-10"
              style={{ bottom: 'calc(env(safe-area-inset-bottom, 0px) + 96px)' }}
            >
              <button
                className="relative"
                onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: video.user.id })}
              >
                <div className="w-11 h-11 rounded-full bg-gray-700 flex items-center justify-center overflow-hidden border-2 border-white">
                  <span className="text-white text-sm font-bold">{video.user.displayName[0]}</span>
                </div>
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center border-2 border-black">
                  <span className="text-white text-[8px] font-bold">+</span>
                </div>
              </button>

              <button
                className="flex flex-col items-center gap-0.5"
                onClick={() => dispatch({ type: 'TOGGLE_LIKE_VIDEO', videoId: video.id })}
              >
                <Heart className={`w-7 h-7 drop-shadow-lg ${video.liked ? 'text-red-500 fill-red-500' : 'text-white'}`} />
                <span className="text-white text-[11px] font-medium drop-shadow">{formatCount(video.likes)}</span>
              </button>

              <button
                className="flex flex-col items-center gap-0.5"
                onClick={() => { setCurrentIndex(index); setShowCommentsSheet(true); }}
              >
                <MessageCircle className="w-7 h-7 text-white drop-shadow-lg" />
                <span className="text-white text-[11px] font-medium drop-shadow">{formatCount(video.comments)}</span>
              </button>

              <button
                className="flex flex-col items-center gap-0.5"
                onClick={() => dispatch({ type: 'TOGGLE_BOOKMARK_VIDEO', videoId: video.id })}
              >
                <Bookmark className={`w-7 h-7 drop-shadow-lg ${video.bookmarked ? 'text-amber-400 fill-amber-400' : 'text-white'}`} />
              </button>

              <button
                className="flex flex-col items-center gap-0.5"
                onClick={() => { setCurrentIndex(index); setShowShareSheet(true); }}
              >
                <Share2 className="w-7 h-7 text-white drop-shadow-lg" />
                <span className="text-white text-[11px] font-medium drop-shadow">{formatCount(video.shares)}</span>
              </button>

              <button className="flex flex-col items-center gap-0.5">
                <MoreVertical className="w-7 h-7 text-white drop-shadow-lg" />
              </button>
            </div>

            {/* Bottom caption */}
            <div
              className="absolute left-4 right-16 z-10"
              style={{ bottom: 'calc(env(safe-area-inset-bottom, 0px) + 88px)' }}
            >
              {video.isLive && (
                <div className="flex items-center gap-1.5 mb-2">
                  <div className="flex items-center gap-1.5 bg-red-600 px-2.5 py-0.5 rounded-md">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse-live" />
                    <span className="text-white text-xs font-bold">LIVE</span>
                  </div>
                  <span className="text-white/80 text-xs">{formatCount(video.viewers || 0)} penonton</span>
                </div>
              )}
              <button
                className="text-white font-bold text-[15px] drop-shadow text-left"
                onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: video.user.id })}
              >
                @{video.user.username}
              </button>
              <p className="text-white text-sm drop-shadow mt-0.5 line-clamp-2 leading-relaxed">{video.caption}</p>
              {video.music && (
                <div className="flex items-center gap-2 mt-2 overflow-hidden">
                  <Music className="w-4 h-4 text-white shrink-0" />
                  <div className="overflow-hidden flex-1">
                    <p className="text-white text-xs drop-shadow whitespace-nowrap animate-marquee">
                      {video.music}&nbsp;&nbsp;&nbsp;&nbsp;{video.music}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Double tap heart animation */}
            {heartAnim && index === currentIndex && (
              <div
                className="absolute z-20 pointer-events-none animate-floatHeart"
                style={{ left: heartAnim.x - 20, top: heartAnim.y - 20 }}
              >
                <Heart className="w-10 h-10 text-red-500 fill-red-500" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ── COMMENTS BOTTOM SHEET ── */}
      {showCommentsSheet && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCommentsSheet(false)} />
          <div className="relative bg-white rounded-t-2xl max-h-[65%] flex flex-col animate-slideUp">
            <div className="flex items-center justify-center py-3 shrink-0">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>
            <div className="flex-1 overflow-y-auto no-scrollbar px-4 space-y-4 pb-2">
              <h3 className="font-semibold text-center text-sm">
                {formatCount(currentVideo?.comments ?? 0)} Komentar
              </h3>
              {[
                { user: 'Ahmad', text: 'Puisinya menyentuh banget! 😭', time: '2m', likes: 24 },
                { user: 'Bella', text: 'Suka banget sama videonya', time: '5m', likes: 12 },
                { user: 'Citra', text: 'Next bikin puisi tentang pagi dong!', time: '10m', likes: 8 },
                { user: 'Dedi', text: 'Keren, lanjutkan karya-karyanya!', time: '15m', likes: 5 },
                { user: 'Eka', text: 'Ini yang aku cari selama ini', time: '20m', likes: 3 },
              ].map((c, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                    <span className="text-xs font-bold">{c.user[0]}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="font-semibold text-sm">{c.user}</span>
                      <span className="text-gray-400 text-xs">{c.time}</span>
                    </div>
                    <p className="text-sm text-gray-700 mt-0.5">{c.text}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <button className="flex items-center gap-1 text-gray-400 text-xs">
                        <Heart className="w-3.5 h-3.5" />{c.likes}
                      </button>
                      <button className="text-gray-400 text-xs">Balas</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div
              className="border-t p-3 flex gap-2 shrink-0"
              style={{ paddingBottom: 'max(12px, env(safe-area-inset-bottom))' }}
            >
              <input
                type="text"
                placeholder="Tambah komentar..."
                className="flex-1 h-10 bg-gray-100 rounded-full px-4 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
              <button className="text-amber-600 font-semibold text-sm">Kirim</button>
            </div>
          </div>
        </div>
      )}

      {/* ── SHARE BOTTOM SHEET ── */}
      {showShareSheet && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowShareSheet(false)} />
          <div className="relative bg-white rounded-t-2xl animate-slideUp">
            <div className="flex items-center justify-center py-3">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>
            <div
              className="p-6"
              style={{ paddingBottom: 'max(24px, env(safe-area-inset-bottom))' }}
            >
              <h3 className="font-semibold text-center mb-4">Bagikan ke</h3>
              <div className="grid grid-cols-4 gap-4">
                {['Salin Tautan', 'WhatsApp', 'Instagram', 'Facebook', 'Twitter', 'Email', 'SMS', 'Lainnya'].map((opt) => (
                  <button key={opt} className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
                      <Share2 className="w-5 h-5 text-gray-600" />
                    </div>
                    <span className="text-xs text-gray-600 text-center">{opt}</span>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowShareSheet(false)}
                className="w-full h-12 mt-6 bg-gray-100 rounded-xl text-gray-700 font-medium"
              >
                Batal
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
