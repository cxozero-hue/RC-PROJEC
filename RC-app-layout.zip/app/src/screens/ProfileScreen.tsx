import { useState } from 'react';
import { Heart, Bookmark, FileText, LogOut, ChevronRight, Camera, Edit3, Bell, Lock, HelpCircle, Info } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { signOut as authSignOut } from '@/lib/authService';

function formatCount(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return n.toString();
}

export default function ProfileScreen() {
  const { state, dispatch } = useApp();
  const [profileTab, setProfileTab] = useState<'works' | 'likes' | 'bookmarks'>('works');
  const [showPhotoOptions, setShowPhotoOptions] = useState(false);

  const user = state.currentUser;
  if (!user) return null;

  const myWorks = [
    ...state.videos.filter(v => v.user.id === user.id),
    ...state.articles.filter(a => a.author.id === user.id),
    ...state.poems.filter(p => p.author.id === user.id),
    ...state.stories.filter(s => s.author.id === user.id),
  ];

  const likedWorks = [
    ...state.videos.filter(v => v.liked),
    ...state.articles.filter(a => a.liked),
    ...state.poems.filter(p => p.liked),
    ...state.stories.filter(s => s.liked),
  ];

  const bookmarkedWorks = [
    ...state.videos.filter(v => v.bookmarked),
    ...state.articles.filter(a => a.bookmarked),
    ...state.poems.filter(p => p.bookmarked),
    ...state.stories.filter(s => s.bookmarked),
  ];

  const menuItems = [
    { icon: Camera, label: 'Upload Foto Profil', action: () => setShowPhotoOptions(true) },
    { icon: Edit3, label: 'Edit Profil', action: () => dispatch({ type: 'NAVIGATE', screen: 'editProfile' }) },
    { icon: Bell, label: 'Notifikasi', action: () => {} },
    { icon: Lock, label: 'Privasi', action: () => {} },
    { icon: HelpCircle, label: 'Bantuan', action: () => {} },
    { icon: Info, label: 'Tentang', action: () => dispatch({ type: 'NAVIGATE', screen: 'about' }) },
  ];

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {/* Profile Header */}
        <div className="relative">
          <div className="h-40 dark-gradient" />
          <div className="px-4 -mt-12 flex flex-col items-center">
            <button
              onClick={() => setShowPhotoOptions(true)}
              className="relative"
            >
              <div className="w-24 h-24 rounded-full border-4 border-white bg-gray-200 flex items-center justify-center overflow-hidden shadow-md">
                {user.avatar ? (
                  <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-3xl font-bold text-gray-400">{user.displayName?.[0] || 'U'}</span>
                )}
              </div>
              <div className="absolute bottom-0 right-0 w-7 h-7 bg-amber-500 rounded-full flex items-center justify-center border-2 border-white">
                <Camera className="w-3.5 h-3.5 text-white" />
              </div>
            </button>
            <h2 className="font-heading text-lg font-bold mt-3">{user.displayName}</h2>
            <p className="text-gray-400 text-sm">@{user.username}</p>
            <p className="text-gray-600 text-sm mt-1 text-center">{user.bio || 'Tambahkan bio...'}</p>

            {/* Stats */}
            <div className="flex items-center gap-8 mt-4">
              <div className="text-center">
                <p className="font-bold text-base">{formatCount(user.following)}</p>
                <p className="text-gray-400 text-xs">Mengikuti</p>
              </div>
              <div className="text-center">
                <p className="font-bold text-base">{formatCount(user.followers)}</p>
                <p className="text-gray-400 text-xs">Pengikut</p>
              </div>
              <div className="text-center">
                <p className="font-bold text-base">{formatCount(user.likes)}</p>
                <p className="text-gray-400 text-xs">Suka</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mt-4 w-full">
              <button
                onClick={() => dispatch({ type: 'NAVIGATE', screen: 'editProfile' })}
                className="flex-1 h-9 border border-gray-200 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5"
              >
                <Edit3 className="w-4 h-4" />
                Edit Profil
              </button>
              <button className="flex-1 h-9 border border-gray-200 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5">
                <Share className="w-4 h-4" />
                Bagikan
              </button>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="flex border-b mt-5 mx-4">
          {[
            { key: 'works' as const, label: 'Karya', icon: FileText },
            { key: 'likes' as const, label: 'Suka', icon: Heart },
            { key: 'bookmarks' as const, label: 'Bookmark', icon: Bookmark },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setProfileTab(tab.key)}
              className={`flex-1 flex items-center justify-center gap-1.5 pb-2.5 text-sm font-medium border-b-2 transition-colors ${
                profileTab === tab.key
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-400'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="px-4 py-4">
          {profileTab === 'works' && (
            myWorks.length > 0 ? (
              <div className="grid grid-cols-3 gap-1">
                {myWorks.map((w: any, i) => (
                  <div key={i} className="aspect-[3/4] bg-gray-200 rounded-lg overflow-hidden relative">
                    {'thumbnail' in w && w.thumbnail ? (
                      <img src={w.thumbnail} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <FileText className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Belum ada karya</p>
                <button
                  onClick={() => dispatch({ type: 'SET_TAB', tab: 'create' })}
                  className="text-amber-600 text-sm font-medium mt-2"
                >
                  Buat karya pertama
                </button>
              </div>
            )
          )}
          {profileTab === 'likes' && (
            likedWorks.length > 0 ? (
              <div className="grid grid-cols-3 gap-1">
                {likedWorks.map((w: any, i) => (
                  <div key={i} className="aspect-[3/4] bg-gray-200 rounded-lg overflow-hidden relative">
                    {'thumbnail' in w && w.thumbnail ? (
                      <img src={w.thumbnail} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <Heart className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Belum ada yang disukai</p>
              </div>
            )
          )}
          {profileTab === 'bookmarks' && (
            bookmarkedWorks.length > 0 ? (
              <div className="grid grid-cols-3 gap-1">
                {bookmarkedWorks.map((w: any, i) => (
                  <div key={i} className="aspect-[3/4] bg-gray-200 rounded-lg overflow-hidden relative">
                    {'thumbnail' in w && w.thumbnail ? (
                      <img src={w.thumbnail} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <Bookmark className="w-8 h-8 text-gray-300" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Bookmark className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Belum ada bookmark</p>
              </div>
            )
          )}
        </div>

        {/* Settings Menu */}
        <div className="px-4 pb-6">
          <h3 className="font-semibold text-sm text-gray-400 uppercase tracking-wide mb-3">Pengaturan</h3>
          <div className="space-y-1">
            {menuItems.map((item, i) => (
              <button
                key={i}
                onClick={item.action}
                className="w-full flex items-center gap-3 py-3 text-left active:bg-gray-50 transition-colors"
              >
                <item.icon className="w-5 h-5 text-gray-500" />
                <span className="flex-1 text-sm">{item.label}</span>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </button>
            ))}
          </div>

          {/* Logout */}
          <button
            onClick={() => {
              if (confirm('Yakin ingin keluar?')) {
                authSignOut().catch(err => console.error('Sign out error:', err));
                dispatch({ type: 'LOGOUT' });
              }
            }}
            className="w-full flex items-center gap-3 py-3 text-left mt-4 text-red-500"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-medium">Keluar</span>
          </button>
        </div>
      </div>

      {/* Photo Options Bottom Sheet */}
      {showPhotoOptions && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowPhotoOptions(false)} />
          <div className="relative bg-white rounded-t-2xl animate-slideUp">
            <div className="flex items-center justify-center py-3">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>
            <div className="p-4 space-y-1">
              <button
                onClick={() => {
                  dispatch({ type: 'UPDATE_PROFILE', user: { avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop' } });
                  setShowPhotoOptions(false);
                  dispatch({ type: 'SHOW_TOAST', message: 'Foto profil diperbarui!' });
                  setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
                }}
                className="w-full py-3 text-left text-base"
              >
                🎲 Pilih Foto Acak
              </button>
              <button className="w-full py-3 text-left text-base text-gray-500">
                📷 Ambil Foto
              </button>
              <button className="w-full py-3 text-left text-base text-gray-500">
                🖼️ Pilih dari Galeri
              </button>
              <button className="w-full py-3 text-left text-base text-red-500">
                🗑️ Hapus Foto
              </button>
              <button
                onClick={() => setShowPhotoOptions(false)}
                className="w-full py-3 mt-2 bg-gray-100 rounded-xl text-center font-medium"
              >
                Batal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Share(props: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={props.className}>
      <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
      <polyline points="16 6 12 2 8 6" />
      <line x1="12" y1="2" x2="12" y2="15" />
    </svg>
  );
}
