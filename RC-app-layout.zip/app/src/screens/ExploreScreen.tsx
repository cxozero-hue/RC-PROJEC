import { useState } from 'react';
import { Search, TrendingUp, Play, FileText, Feather, BookOpen } from 'lucide-react';
import { useApp } from '@/context/AppContext';

const trendingHashtags = [
  { tag: '#PuisiPagi', count: '45.2K video' },
  { tag: '#CerpenHoror', count: '23.1K video' },
  { tag: '#MenulisBersama', count: '18.7K video' },
  { tag: '#BukuReview', count: '34.5K video' },
  { tag: '#SastraNusantara', count: '12.3K video' },
  { tag: '#LiveMenulis', count: '8.9K video' },
];

const categories = [
  { name: 'Puisi', icon: Feather, color: 'bg-amber-100 text-amber-600' },
  { name: 'Cerpen', icon: BookOpen, color: 'bg-purple-100 text-purple-600' },
  { name: 'Artikel', icon: FileText, color: 'bg-green-100 text-green-600' },
  { name: 'Tutorial', icon: Play, color: 'bg-blue-100 text-blue-600' },
];

export default function ExploreScreen() {
  const { state, dispatch } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const filteredVideos = state.videos.filter(v =>
    searchQuery
      ? v.caption.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.user.username.toLowerCase().includes(searchQuery.toLowerCase())
      : true
  );

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Search Bar */}
      <div className="shrink-0 px-4 pt-3 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Cari video, penulis, tagar..."
            className="w-full h-11 bg-gray-100 rounded-xl pl-10 pr-4 text-[15px] focus:outline-none focus:ring-2 focus:ring-amber-400"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {!searchQuery ? (
          <>
            {/* Trending Hashtags */}
            <div className="px-4 py-3">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-5 h-5 text-red-500" />
                <h2 className="font-semibold text-base">Sedang Trending</h2>
              </div>
              <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                {trendingHashtags.map((t) => (
                  <button
                    key={t.tag}
                    className="shrink-0 bg-gray-100 rounded-xl px-4 py-3 text-left active:bg-gray-200 transition-colors"
                  >
                    <p className="font-semibold text-sm">{t.tag}</p>
                    <p className="text-gray-400 text-xs mt-0.5">{t.count}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Categories */}
            <div className="px-4 py-3">
              <h2 className="font-semibold text-base mb-3">Kategori</h2>
              <div className="grid grid-cols-4 gap-3">
                {categories.map((cat) => (
                  <button key={cat.name} className="flex flex-col items-center gap-2">
                    <div className={`w-14 h-14 rounded-2xl ${cat.color} flex items-center justify-center`}>
                      <cat.icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-medium">{cat.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Suggested Users */}
            <div className="px-4 py-3">
              <h2 className="font-semibold text-base mb-3">Penulis Populer</h2>
              <div className="space-y-3">
                {state.videos.slice(0, 5).map(v => (
                  <button
                    key={v.user.id}
                    className="flex items-center gap-3 w-full text-left"
                    onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: v.user.id })}
                  >
                    <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                      <span className="font-bold text-gray-600">{v.user.displayName[0]}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{v.user.displayName}</p>
                      <p className="text-gray-400 text-xs">@{v.user.username}</p>
                    </div>
                    <div className="bg-amber-50 text-amber-600 text-xs font-medium px-3 py-1.5 rounded-full">
                      Ikuti
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Search Results */}
            <div className="px-4 py-2">
              <p className="text-gray-400 text-sm mb-3">Hasil pencarian untuk &quot;{searchQuery}&quot;</p>
              <div className="grid grid-cols-2 gap-1">
                {filteredVideos.map(v => (
                  <button key={v.id} className="relative aspect-[3/4] bg-gray-200">
                    <img src={v.thumbnail} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/20" />
                    <div className="absolute bottom-2 left-2 flex items-center gap-1">
                      <Play className="w-3.5 h-3.5 text-white fill-white" />
                      <span className="text-white text-[11px]">{v.likes}</span>
                    </div>
                  </button>
                ))}
              </div>
              {filteredVideos.length === 0 && (
                <div className="text-center py-12">
                  <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-400">Tidak ada hasil</p>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
