import { ArrowLeft, Heart, MessageCircle, Share2, Bookmark, Clock, Eye } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function ArticleDetailScreen() {
  const { state, dispatch } = useApp();
  const article = state.articles.find(a => a.id === state.selectedArticleId);

  if (!article) return null;

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 h-14 border-b bg-white z-10">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <span className="font-semibold text-sm">{article.category}</span>
        <div className="flex items-center gap-2">
          <button onClick={() => dispatch({ type: 'TOGGLE_BOOKMARK_ARTICLE', articleId: article.id })}>
            <Bookmark className={`w-5 h-5 ${article.bookmarked ? 'text-amber-500 fill-amber-500' : 'text-gray-600'}`} />
          </button>
          <button><Share2 className="w-5 h-5 text-gray-600" /></button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {/* Thumbnail */}
        <img src={article.thumbnail} alt={article.title} className="w-full aspect-video object-cover" />

        {/* Content */}
        <div className="p-4">
          <h1 className="font-heading text-xl font-bold leading-snug">{article.title}</h1>

          <div className="flex items-center gap-3 mt-3">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
              <span className="text-xs font-bold">{article.author.displayName[0]}</span>
            </div>
            <div>
              <p className="text-sm font-medium">{article.author.displayName}</p>
              <p className="text-gray-400 text-xs">{article.publishedAt} • <Clock className="w-3 h-3 inline" /> {article.readTime}</p>
            </div>
            <button
              onClick={() => dispatch({ type: 'SET_SELECTED_USER', userId: article.author.id })}
              className="ml-auto gold-gradient text-white text-xs font-semibold px-3 py-1.5 rounded-full"
            >
              Ikuti
            </button>
          </div>

          <div className="border-t my-4" />

          <div className="prose prose-sm max-w-none">
            <p className="text-base leading-relaxed text-gray-700 whitespace-pre-line">{article.content}</p>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="shrink-0 border-t bg-white px-4 py-2 flex items-center justify-between">
        <button
          onClick={() => dispatch({ type: 'TOGGLE_LIKE_ARTICLE', articleId: article.id })}
          className={`flex items-center gap-1.5 ${article.liked ? 'text-red-500' : 'text-gray-600'}`}
        >
          <Heart className={`w-5 h-5 ${article.liked ? 'fill-red-500' : ''}`} />
          <span className="text-sm">{article.likes}</span>
        </button>
        <button className="flex items-center gap-1.5 text-gray-600">
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm">{article.comments}</span>
        </button>
        <div className="flex items-center gap-1 text-gray-400 text-xs">
          <Eye className="w-4 h-4" />
          {article.readCount}
        </div>
        <button><Share2 className="w-5 h-5 text-gray-600" /></button>
      </div>
    </div>
  );
}
