import { ArrowLeft, Globe, Mail, ExternalLink, Instagram, Twitter, Facebook, Heart } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function AboutScreen() {
  const { dispatch } = useApp();

  return (
    <div className="h-full flex flex-col dark-gradient overflow-y-auto no-scrollbar">
      {/* Header */}
      <div className="shrink-0 flex items-center px-4 h-14">
        <button onClick={() => dispatch({ type: 'GO_BACK' })} className="w-10 h-10 flex items-center justify-center -ml-2">
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <h1 className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="text-white font-semibold text-base">Tentang Kami</span>
        </h1>
      </div>

      <div className="flex-1 px-6 pb-8">
        {/* Logo */}
        <div className="flex flex-col items-center py-8">
          <div className="w-20 h-20 rounded-full gold-gradient flex items-center justify-center mb-4">
            <Globe className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-white font-heading text-xl font-bold">Zero Coordinates</h2>
          <p className="text-gray-400 text-sm mt-1 text-center">
            Membangun Ruang Digital untuk Kreativitas
          </p>
        </div>

        {/* Divider */}
        <div className="w-16 h-px bg-gray-700 mx-auto mb-6" />

        {/* Vision */}
        <div className="mb-8">
          <h3 className="text-amber-400 font-semibold text-base mb-2">Visi Kami</h3>
          <p className="text-white text-sm leading-relaxed">
            Menciptakan platform di mana setiap suara memiliki tempat, setiap cerita mendapat ruang, 
            dan setiap karya sastra dapat diakses oleh semua orang. Kami percaya bahwa literasi adalah 
            kunci untuk membangun masyarakat yang lebih berpengetahuan dan berempati.
          </p>
        </div>

        {/* Mission */}
        <div className="mb-8">
          <h3 className="text-amber-400 font-semibold text-base mb-2">Misi Kami</h3>
          <ul className="space-y-3">
            {[
              'Memberdayakan penulis dan kreator konten literasi',
              'Membangun komunitas pembaca dan penulis yang inklusif',
              'Melestarikan dan mempromosikan sastra Indonesia',
              'Menggunakan teknologi untuk memperluas akses literasi',
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full gold-gradient flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-white text-[10px] font-bold">{i + 1}</span>
                </div>
                <p className="text-gray-300 text-sm">{item}</p>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div className="mb-8">
          <h3 className="text-amber-400 font-semibold text-base mb-3">Hubungi Kami</h3>
          <div className="space-y-3">
            <button className="w-full flex items-center gap-3 py-2 text-left">
              <Mail className="w-5 h-5 text-gray-400" />
              <span className="text-gray-300 text-sm">support@ruangcerita.id</span>
            </button>
            <button className="w-full flex items-center gap-3 py-2 text-left">
              <ExternalLink className="w-5 h-5 text-gray-400" />
              <span className="text-gray-300 text-sm">www.ruangcerita.id</span>
            </button>
          </div>
        </div>

        {/* Social Media */}
        <div className="mb-8">
          <h3 className="text-amber-400 font-semibold text-base mb-3">Media Sosial</h3>
          <div className="flex gap-4">
            <button className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
              <Instagram className="w-5 h-5 text-white" />
            </button>
            <button className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
              <Twitter className="w-5 h-5 text-white" />
            </button>
            <button className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
              <Facebook className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center pt-4 border-t border-gray-800">
          <div className="flex items-center justify-center gap-1 text-gray-500 text-xs mb-2">
            <span>Dibuat dengan</span>
            <Heart className="w-3 h-3 text-red-500 fill-red-500" />
            <span>oleh Zero Coordinates</span>
          </div>
          <p className="text-gray-600 text-xs">Ruang Cerita v1.0.0</p>
          <p className="text-gray-700 text-xs mt-1">© 2024 Zero Coordinates. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
