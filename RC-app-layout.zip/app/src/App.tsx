import { useEffect } from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import BottomNav from '@/components/BottomNav';
import LoginScreen from '@/screens/LoginScreen';
import RegisterScreen from '@/screens/RegisterScreen';
import VideoFeedScreen from '@/screens/VideoFeedScreen';
import ExploreScreen from '@/screens/ExploreScreen';
import CreateScreen from '@/screens/CreateScreen';
import LiteratureScreen from '@/screens/LiteratureScreen';
import ProfileScreen from '@/screens/ProfileScreen';
import EditProfileScreen from '@/screens/EditProfileScreen';
import ChatListScreen from '@/screens/ChatListScreen';
import ChatDetailScreen from '@/screens/ChatDetailScreen';
import ArticleDetailScreen from '@/screens/ArticleDetailScreen';
import PoemDetailScreen from '@/screens/PoemDetailScreen';
import StoryDetailScreen from '@/screens/StoryDetailScreen';
import LiveScreen from '@/screens/LiveScreen';
import AboutScreen from '@/screens/AboutScreen';
import UserProfileScreen from '@/screens/UserProfileScreen';
import type { Screen } from '@/types';

const tabRoots: Screen[] = ['videoFeed', 'explore', 'create', 'literature', 'profile'];

function ScreenRouter() {
  const { state, dispatch } = useApp();

  useEffect(() => {
    if (state.toast?.visible) {
      const timer = setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), state.toast?.duration ?? 3000);
      return () => clearTimeout(timer);
    }
  }, [state.toast, dispatch]);

  const renderScreen = () => {
    if (state.authLoading) {
      return (
        <div className="h-full flex flex-col items-center justify-center dark-gradient">
          <div className="w-20 h-20 rounded-2xl overflow-hidden shadow-xl shadow-amber-500/20 mb-4 animate-pulse">
            <img src="/logo.jpg" alt="Ruang Cerita" className="w-full h-full object-cover" />
          </div>
          <div className="w-6 h-6 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
        </div>
      );
    }
    switch (state.screen) {
      case 'login':
        return <LoginScreen />;
      case 'register':
        return <RegisterScreen />;
      case 'videoFeed':
        return <VideoFeedScreen />;
      case 'explore':
        return <ExploreScreen />;
      case 'create':
        return <CreateScreen />;
      case 'literature':
        return <LiteratureScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'editProfile':
        return <EditProfileScreen />;
      case 'chatList':
        return <ChatListScreen />;
      case 'chatDetail':
        return <ChatDetailScreen />;
      case 'articleDetail':
        return <ArticleDetailScreen />;
      case 'poemDetail':
        return <PoemDetailScreen />;
      case 'storyDetail':
        return <StoryDetailScreen />;
      case 'live':
        return <LiveScreen />;
      case 'about':
        return <AboutScreen />;
      case 'userProfile':
        return <UserProfileScreen />;
      default:
        return <VideoFeedScreen />;
    }
  };

  const showNav = state.isAuthenticated && tabRoots.includes(state.screen);

  return (
    <div className="h-screen w-full bg-neutral-900 flex justify-center items-center p-0 md:p-4">
      {/* Mobile Container - uses JS-computed height (--app-height) for reliable
          full-screen sizing across all Android WebView versions and screen sizes,
          since 'dvh' units are not consistently supported on older WebViews. */}
      <div
        className="w-full max-w-[430px] md:h-[850px] bg-white rounded-none overflow-hidden shadow-2xl relative isolate flex flex-col"
        style={{ height: 'var(--app-height, 100vh)' }}
      >
        {/* Main Content */}
        <main className="flex-1 overflow-hidden min-h-0">
          {renderScreen()}
        </main>

        {/* Create Options Bottom Sheet */}
        {state.showCreateOptions && (
          <div className="absolute inset-0 z-50 flex flex-col justify-end">
            <div className="absolute inset-0 bg-black/50" onClick={() => dispatch({ type: 'SET_SHOW_CREATE', show: false })} />
            <div className="relative bg-white rounded-t-2xl animate-slideUp">
              <div className="flex items-center justify-center py-3">
                <div className="w-10 h-1 bg-gray-300 rounded-full" />
              </div>
              <div className="p-6">
                <h3 className="font-heading text-lg font-bold text-center mb-1">Buat</h3>
                <p className="text-gray-400 text-sm text-center mb-6">Pilih jenis konten yang ingin dibagikan</p>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { key: 'video', label: 'Video', desc: 'Rekam video', color: 'bg-blue-50 text-blue-500', action: () => { dispatch({ type: 'SET_SHOW_CREATE', show: false }); dispatch({ type: 'SHOW_TOAST', message: 'Fitur video segera hadir!' }); } },
                    { key: 'story', label: 'Cerpen', desc: 'Tulis cerita', color: 'bg-purple-50 text-purple-500', action: () => { dispatch({ type: 'SET_SHOW_CREATE', show: false }); dispatch({ type: 'SET_TAB', tab: 'literature' }); setTimeout(() => dispatch({ type: 'NAVIGATE', screen: 'uploadLiterature' }), 100); } },
                    { key: 'poem', label: 'Puisi', desc: 'Tulis puisi', color: 'bg-amber-50 text-amber-500', action: () => { dispatch({ type: 'SET_SHOW_CREATE', show: false }); dispatch({ type: 'SET_TAB', tab: 'literature' }); } },
                    { key: 'article', label: 'Artikel', desc: 'Tulis artikel', color: 'bg-green-50 text-green-500', action: () => { dispatch({ type: 'SET_SHOW_CREATE', show: false }); dispatch({ type: 'SET_TAB', tab: 'literature' }); } },
                    { key: 'live', label: 'Live', desc: 'Siaran langsung', color: 'bg-red-50 text-red-500', action: () => { dispatch({ type: 'SET_SHOW_CREATE', show: false }); dispatch({ type: 'NAVIGATE', screen: 'live' }); } },
                    { key: 'gallery', label: 'Galeri', desc: 'Dari galeri', color: 'bg-orange-50 text-orange-500', action: () => { dispatch({ type: 'SET_SHOW_CREATE', show: false }); dispatch({ type: 'SHOW_TOAST', message: 'Fitur galeri segera hadir!' }); } },
                  ].map(opt => (
                    <button
                      key={opt.key}
                      onClick={() => {
                        opt.action();
                        setTimeout(() => dispatch({ type: 'HIDE_TOAST' }), 3000);
                      }}
                      className="flex flex-col items-center gap-2 bg-gray-50 rounded-2xl p-4 active:bg-gray-100 transition-colors"
                    >
                      <div className={`w-12 h-12 rounded-xl ${opt.color} flex items-center justify-center`}>
                        <span className="text-xl">{opt.key === 'video' ? '🎥' : opt.key === 'story' ? '📖' : opt.key === 'poem' ? '✒️' : opt.key === 'article' ? '📝' : opt.key === 'live' ? '🔴' : '🖼️'}</span>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-sm">{opt.label}</p>
                        <p className="text-gray-400 text-[11px]">{opt.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => dispatch({ type: 'SET_SHOW_CREATE', show: false })}
                  className="w-full h-12 mt-6 bg-gray-100 rounded-xl text-gray-700 font-medium"
                >
                  Batal
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Toast */}
        {state.toast?.visible && (
          <div className="absolute top-6 left-4 right-4 z-[70] animate-fadeIn">
            <div className="bg-gray-900 text-white px-4 py-3 rounded-xl text-sm font-medium shadow-lg text-center">
              {state.toast.message}
            </div>
          </div>
        )}

        {/* Bottom Navigation */}
        {showNav && <BottomNav />}
      </div>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <ScreenRouter />
    </AppProvider>
  );
}

export default App;
