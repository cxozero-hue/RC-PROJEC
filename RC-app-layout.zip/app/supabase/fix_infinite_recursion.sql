-- =========================================================
-- PERBAIKAN BUG: "infinite recursion detected in policy for
-- relation conversation_participants"
--
-- Akar masalah: policy SELECT di conversation_participants meng-query
-- dirinya sendiri, dan policy INSERT yang baru ditambahkan memanggil
-- tabel conversations yang policy SELECT-nya balik lagi ke
-- conversation_participants -> rekursi tanpa henti.
--
-- Solusi: pakai SECURITY DEFINER function yang membaca tabel tanpa
-- memicu RLS lagi, memutus rantai rekursi sepenuhnya.
--
-- Jalankan SEKALI di SQL Editor Supabase.
-- =========================================================

-- 1. Buat helper functions yang bypass RLS (SECURITY DEFINER)
create or replace function public.is_conversation_participant(p_conversation_id uuid, p_user_id uuid)
returns boolean as $$
  select exists (
    select 1 from public.conversation_participants
    where conversation_id = p_conversation_id and user_id = p_user_id
  );
$$ language sql security definer stable;

create or replace function public.get_conversation_creator(p_conversation_id uuid)
returns uuid as $$
  select created_by from public.conversations where id = p_conversation_id;
$$ language sql security definer stable;

-- 2. Hapus semua policy lama yang sirkular (aman walau belum ada)
drop policy if exists "Users can view participants of their conversations" on public.conversation_participants;
drop policy if exists "Users can add participants when creating conversation" on public.conversation_participants;
drop policy if exists "Creator can add participants to their new conversation" on public.conversation_participants;
drop policy if exists "Users can view conversations they belong to" on public.conversations;
drop policy if exists "Authenticated users can create conversations" on public.conversations;
drop policy if exists "Users can view messages in their conversations" on public.messages;
drop policy if exists "Users can send messages to their conversations" on public.messages;
drop policy if exists "Users can update read status of messages in their conversations" on public.messages;

-- 3. Buat ulang semua policy memakai helper function (tidak ada rekursi lagi)
create policy "Users can view participants of their conversations"
  on public.conversation_participants for select
  using (
    public.is_conversation_participant(conversation_id, auth.uid())
  );

create policy "Creator can add participants to their new conversation"
  on public.conversation_participants for insert
  with check (
    auth.uid() = user_id
    or auth.uid() = public.get_conversation_creator(conversation_id)
  );

create policy "Users can view conversations they belong to"
  on public.conversations for select
  using (
    public.is_conversation_participant(id, auth.uid())
  );

create policy "Authenticated users can create conversations"
  on public.conversations for insert
  with check (auth.uid() is not null and auth.uid() = created_by);

create policy "Users can view messages in their conversations"
  on public.messages for select
  using (
    public.is_conversation_participant(conversation_id, auth.uid())
  );

create policy "Users can send messages to their conversations"
  on public.messages for insert
  with check (
    auth.uid() = sender_id
    and public.is_conversation_participant(conversation_id, auth.uid())
  );

create policy "Users can update read status of messages in their conversations"
  on public.messages for update
  using (
    public.is_conversation_participant(conversation_id, auth.uid())
  );

-- 4. Verifikasi: tampilkan semua policy yang aktif sekarang
select schemaname, tablename, policyname, cmd
from pg_policies
where tablename in ('conversations', 'conversation_participants', 'messages')
order by tablename, cmd;
