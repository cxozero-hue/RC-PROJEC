-- =========================================================
-- Ruang Cerita - Skema Database untuk Fitur Chat & Upload Gambar
-- Jalankan seluruh file ini di Supabase SQL Editor
-- =========================================================

-- 1. Tabel PROFILES (data publik pengguna, terhubung ke auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default '',
  avatar_url text,
  bio text default '',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Profiles are viewable by everyone"
  on public.profiles for select
  using (true);

create policy "Users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Otomatis buat baris profile saat user baru daftar
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 2. Tabel CONVERSATIONS (percakapan antar 2 atau lebih pengguna)
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.conversations enable row level security;

-- 3. Tabel CONVERSATION_PARTICIPANTS (siapa saja yang ada di percakapan)
create table if not exists public.conversation_participants (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

alter table public.conversation_participants enable row level security;

-- PENTING: Untuk menghindari "infinite recursion" di RLS Postgres, kita pakai
-- helper function SECURITY DEFINER yang membaca tabel TANPA memicu RLS lagi.
-- Tanpa ini, policy SELECT/INSERT di conversations dan conversation_participants
-- akan saling memanggil satu sama lain secara sirkular tanpa henti.
create or replace function public.is_conversation_participant(p_conversation_id uuid, p_user_id uuid)
returns boolean as $$
  select exists (
    select 1 from public.conversation_participants
    where conversation_id = p_conversation_id and user_id = p_user_id
  );
$$ language sql security definer stable;

create or replace function public.get_conversation_creator(p_conversation_id uuid)
returns uuid as $$
  select created_by from public.conversations where id = p_conversation_id;
$$ language sql security definer stable;

create policy "Users can view participants of their conversations"
  on public.conversation_participants for select
  using (
    public.is_conversation_participant(conversation_id, auth.uid())
  );

create policy "Creator can add participants to their new conversation"
  on public.conversation_participants for insert
  with check (
    auth.uid() = user_id
    or auth.uid() = public.get_conversation_creator(conversation_id)
  );

create policy "Users can view conversations they belong to"
  on public.conversations for select
  using (
    public.is_conversation_participant(id, auth.uid())
  );

create policy "Authenticated users can create conversations"
  on public.conversations for insert
  with check (auth.uid() is not null and auth.uid() = created_by);

-- 4. Tabel MESSAGES (isi pesan, termasuk gambar)
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references public.conversations(id) on delete cascade not null,
  sender_id uuid references public.profiles(id) on delete cascade not null,
  content text default '',
  image_url text,
  created_at timestamptz not null default now(),
  is_read boolean not null default false
);

alter table public.messages enable row level security;

create policy "Users can view messages in their conversations"
  on public.messages for select
  using (
    public.is_conversation_participant(conversation_id, auth.uid())
  );

create policy "Users can send messages to their conversations"
  on public.messages for insert
  with check (
    auth.uid() = sender_id
    and public.is_conversation_participant(conversation_id, auth.uid())
  );

create policy "Users can update read status of messages in their conversations"
  on public.messages for update
  using (
    public.is_conversation_participant(conversation_id, auth.uid())
  );

-- 5. Aktifkan Realtime untuk tabel messages (supaya pesan baru muncul otomatis)
alter publication supabase_realtime add table public.messages;

-- 6. Trigger untuk update updated_at di conversations setiap ada pesan baru
create or replace function public.touch_conversation()
returns trigger as $$
begin
  update public.conversations set updated_at = now() where id = new.conversation_id;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_message_inserted on public.messages;
create trigger on_message_inserted
  after insert on public.messages
  for each row execute procedure public.touch_conversation();

-- 7. Storage bucket untuk gambar chat
insert into storage.buckets (id, name, public)
values ('chat-images', 'chat-images', true)
on conflict (id) do nothing;

create policy "Anyone can view chat images"
  on storage.objects for select
  using (bucket_id = 'chat-images');

create policy "Authenticated users can upload chat images"
  on storage.objects for insert
  with check (bucket_id = 'chat-images' and auth.uid() is not null);

-- 8. Storage bucket untuk avatar profil (bonus, untuk kelengkapan profil)
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

create policy "Anyone can view avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "Authenticated users can upload their avatar"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.uid() is not null);

-- =========================================================
-- Selesai. Setelah ini jalan tanpa error, fitur chat + upload
-- gambar siap dipakai dari aplikasi.
-- =========================================================
