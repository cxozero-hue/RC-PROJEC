-- =========================================================
-- PERBAIKAN BUG: RLS policy untuk conversation_participants
-- punya logika sirkular yang menyebabkan "Gagal memulai percakapan".
-- Jalankan SEKALI di SQL Editor Supabase untuk database yang sudah berjalan.
-- =========================================================

-- 1. Tambah kolom created_by ke tabel conversations (kalau belum ada)
alter table public.conversations
  add column if not exists created_by uuid references public.profiles(id);

-- 2. Hapus policy lama yang bermasalah (sirkular), dan policy baru juga
--    (kalau sudah pernah dibuat sebagian, supaya script ini aman dijalankan berkali-kali)
drop policy if exists "Users can add participants when creating conversation" on public.conversation_participants;
drop policy if exists "Creator can add participants to their new conversation" on public.conversation_participants;
drop policy if exists "Authenticated users can create conversations" on public.conversations;

-- 3. Buat ulang policy dengan logika yang benar
create policy "Creator can add participants to their new conversation"
  on public.conversation_participants for insert
  with check (
    auth.uid() = user_id
    or auth.uid() = (select created_by from public.conversations where id = conversation_id)
  );

create policy "Authenticated users can create conversations"
  on public.conversations for insert
  with check (auth.uid() is not null and auth.uid() = created_by);

-- 4. Verifikasi: tampilkan semua policy yang aktif sekarang untuk dicek manual
select schemaname, tablename, policyname, cmd
from pg_policies
where tablename in ('conversations', 'conversation_participants')
order by tablename, cmd;
