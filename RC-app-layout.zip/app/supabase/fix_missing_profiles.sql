-- =========================================================
-- PERBAIKAN: Backfill profile yang hilang untuk akun yang sudah
-- terdaftar sebelumnya (jika trigger handle_new_user gagal jalan).
-- Jalankan ini SEKALI di SQL Editor Supabase setelah update kode.
-- =========================================================

insert into public.profiles (id, username, display_name)
select
  u.id,
  coalesce(u.raw_user_meta_data->>'username', split_part(u.email, '@', 1)) as username,
  coalesce(u.raw_user_meta_data->>'display_name', split_part(u.email, '@', 1)) as display_name
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null;

-- Cek hasil: tampilkan semua profile yang sekarang ada
select id, username, display_name, created_at from public.profiles order by created_at desc;
