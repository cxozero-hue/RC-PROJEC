# Fitur Chat Real-Time & Upload Gambar — Panduan Setup

Aplikasi sekarang terhubung ke backend sungguhan (Supabase) untuk:
- Login & Register dengan akun asli (email/password)
- Chat real-time antar pengguna (pesan langsung muncul tanpa refresh)
- Kirim gambar dalam chat

## Langkah 1 — Jalankan skema database

Sebelum aplikasi bisa dipakai, jalankan dulu skema database di Supabase:

1. Buka dashboard Supabase project Anda (`ruang-cerita`)
2. Di sidebar kiri, cari menu **SQL Editor**
3. Buka file `supabase/schema.sql` di folder project ini, copy semua isinya
4. Paste ke SQL Editor di Supabase
5. Klik **Run** (atau tombol play ▶️)
6. Pastikan tidak ada error — kalau sukses akan muncul "Success. No rows returned"

Skema ini membuat:
- Tabel `profiles`, `conversations`, `conversation_participants`, `messages`
- Aturan keamanan (Row Level Security) supaya pengguna hanya bisa lihat chat miliknya sendiri
- Storage bucket `chat-images` untuk menyimpan gambar yang dikirim di chat
- Realtime aktif untuk tabel `messages`, supaya pesan baru langsung muncul

## Langkah 2 — Konfigurasi sudah otomatis

File `.env` di project ini sudah diisi dengan URL dan publishable key project Supabase Anda. Tidak perlu setting tambahan — saat di-build (baik lokal maupun lewat GitHub Actions), aplikasi otomatis terhubung ke project Supabase tersebut.

## Langkah 3 — Build & Test

Ikuti proses build APK yang sama seperti sebelumnya (upload ke GitHub, GitHub Actions otomatis build).

## Cara Pakai di Aplikasi

1. **Daftar akun baru** lewat halaman Register (ID pengguna + kata sandi)
2. Setelah daftar, langsung masuk ke aplikasi
3. Buka tab **Pesan** → tap ikon pensil (✏️) di pojok kanan atas → cari ID pengguna lain
4. Tap nama pengguna untuk mulai chat
5. Kirim pesan teks dan/atau gambar (ikon 🖼️ di sebelah kotak teks)
6. Karena ini realtime, kalau ada 2 device/akun berbeda yang chat satu sama lain, pesan akan muncul otomatis tanpa refresh

## Catatan Penting

- **Untuk testing**, Anda perlu membuat **minimal 2 akun berbeda** (misal lewat 2 device, atau logout-login bergantian) untuk benar-benar mencoba kirim-terima pesan.
- Email yang dipakai Supabase Auth di belakang layar adalah `[ID-pengguna]@ruangcerita.local` — ini otomatis, pengguna tidak perlu tahu/memasukkan email asli.
- Ukuran gambar dibatasi maksimal 5MB per kirim.
- Project Supabase gratis (free tier) punya batas: 500MB database, 1GB file storage, 2GB transfer bandwidth/bulan — cukup untuk testing dan penggunaan skala kecil.
