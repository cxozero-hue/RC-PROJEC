import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ruangcerita.app',
  appName: 'Ruang Cerita',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
