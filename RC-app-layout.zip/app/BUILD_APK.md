# Build APK Otomatis (GitHub Actions)

Project ini sudah dikonfigurasi dengan Capacitor + GitHub Actions, supaya APK Android
dibuild otomatis di cloud — tanpa perlu install Android Studio di laptop.

## Langkah-langkah

1. **Buat repository baru di GitHub** (boleh privat atau publik).

2. **Upload seluruh isi folder `app/` ini** ke repository tersebut.
   Caranya bisa lewat web GitHub (drag & drop semua file/folder), atau lewat git:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/USERNAME/NAMA-REPO.git
   git push -u origin main
   ```

3. Setelah push, buka tab **Actions** di repository GitHub Anda.
   Workflow "Build Android APK" akan otomatis berjalan (butuh beberapa menit).

4. Setelah selesai (centang hijau ✅), klik workflow run tersebut, scroll ke bagian
   **Artifacts**, lalu download `ruang-cerita-debug-apk`. Itu adalah file `.apk` siap install.

5. Pindahkan file `.apk` ke HP Android (lewat USB, Google Drive, dll), lalu install.
   - Android mungkin minta izin "Install dari sumber tidak dikenal" — aktifkan untuk
     file ini saja.

## Menjalankan ulang build

Setiap kali Anda push perubahan kode ke branch `main`, APK akan dibuild ulang otomatis.
Anda juga bisa trigger manual lewat tab Actions → "Build Android APK" → "Run workflow".

## Catatan

- APK yang dihasilkan adalah **debug build** — cocok untuk testing/instalasi pribadi.
  Untuk publish ke Google Play Store, perlu langkah tambahan (signing dengan keystore
  release) — beri tahu saya kalau sudah sampai tahap itu.
- App ID: `com.ruangcerita.app` — bisa diganti di `capacitor.config.ts` sebelum push
  pertama kali jika perlu.
- Ikon app dan splash screen sudah otomatis digenerate dari logo "Ruang Cerita"
  (file sumbernya ada di folder `resources/`) — tidak perlu langkah tambahan.
